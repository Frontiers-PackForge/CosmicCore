package com.gregtechceu.gtceu.api.item.tool.behavior;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import com.mojang.serialization.Codec;

public class ToolBehaviorType<T extends IToolBehavior<T>> {
    public final Codec<T> codec;
    public final StreamCodec<? super RegistryFriendlyByteBuf, T> streamCodec;

    public ToolBehaviorType(final Codec<T> codec, final StreamCodec<? super RegistryFriendlyByteBuf, T> streamCodec) {
        this.codec = codec;
        this.streamCodec = streamCodec;
    }

    public Codec<T> getCodec() {
        return this.codec;
    }

    public StreamCodec<? super RegistryFriendlyByteBuf, T> getStreamCodec() {
        return this.streamCodec;
    }
}
