package com.gregtechceu.gtceu.api.item.datacomponents;

import com.gregtechceu.gtceu.api.item.armor.ArmorUtils;
import com.gregtechceu.gtceu.utils.codec.StreamCodecUtils;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;

public record GTArmor(boolean enabled, boolean hover, boolean canShare, boolean nightVision, boolean boostedJump, boolean onGround, boolean stepAssist, byte toggleTimer, short burnTimer, int nightVisionTimer, byte runningTimer, byte boostedJumpTimer, byte consumerTicks) {
    // spotless:off
    public static final Codec<GTArmor> CODEC = RecordCodecBuilder.create(instance -> instance.group(Codec.BOOL.orElse(false).fieldOf("enabled").forGetter(GTArmor::enabled), Codec.BOOL.orElse(false).fieldOf("hover").forGetter(GTArmor::hover), Codec.BOOL.orElse(false).fieldOf("can_share").forGetter(GTArmor::canShare), Codec.BOOL.orElse(false).fieldOf("night_vision").forGetter(GTArmor::nightVision), Codec.BOOL.orElse(false).fieldOf("boosted_jump").forGetter(GTArmor::boostedJump), Codec.BOOL.orElse(false).fieldOf("on_ground").forGetter(GTArmor::onGround), Codec.BOOL.orElse(false).fieldOf("step_assist").forGetter(GTArmor::stepAssist), Codec.BYTE.orElse((byte) 0).fieldOf("toggle_timer").forGetter(GTArmor::toggleTimer), Codec.SHORT.orElse((short) 0).fieldOf("burn_timer").forGetter(GTArmor::burnTimer), Codec.INT.orElse(ArmorUtils.NIGHTVISION_DURATION).fieldOf("night_vision_timer").forGetter(GTArmor::nightVisionTimer), Codec.BYTE.orElse((byte) 0).fieldOf("running_timer").forGetter(GTArmor::runningTimer), Codec.BYTE.orElse((byte) 0).fieldOf("boosted_jump_timer").forGetter(GTArmor::boostedJumpTimer), Codec.BYTE.orElse((byte) 0).fieldOf("consumer_ticks").forGetter(GTArmor::consumerTicks)).apply(instance, GTArmor::new));
    // spotless:on
    public static final StreamCodec<ByteBuf, GTArmor> STREAM_CODEC = StreamCodecUtils.composite(ByteBufCodecs.BOOL, GTArmor::enabled, ByteBufCodecs.BOOL, GTArmor::hover, ByteBufCodecs.BOOL, GTArmor::canShare, ByteBufCodecs.BOOL, GTArmor::nightVision, ByteBufCodecs.BOOL, GTArmor::boostedJump, ByteBufCodecs.BOOL, GTArmor::onGround, ByteBufCodecs.BOOL, GTArmor::stepAssist, ByteBufCodecs.BYTE, GTArmor::toggleTimer, ByteBufCodecs.SHORT, GTArmor::burnTimer, ByteBufCodecs.VAR_INT, GTArmor::nightVisionTimer, ByteBufCodecs.BYTE, GTArmor::runningTimer, ByteBufCodecs.BYTE, GTArmor::boostedJumpTimer, ByteBufCodecs.BYTE, GTArmor::consumerTicks, GTArmor::new);
    public static final GTArmor EMPTY = new GTArmor();

    private GTArmor() {
        this(false, false, false, false, false, false, false, (byte) 0, (short) 0, 0, (byte) 0, (byte) 0, (byte) 0);
    }

    public GTArmor setEnabled(boolean enabled) {
        return new GTArmor(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
    }

    public GTArmor setHover(boolean hover) {
        return new GTArmor(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
    }

    public GTArmor setCanShare(boolean canShare) {
        return new GTArmor(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
    }

    public GTArmor setNightVision(boolean nightVision) {
        return new GTArmor(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
    }

    public GTArmor setBoostedJump(boolean boostedJump) {
        return new GTArmor(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
    }

    public GTArmor setOnGround(boolean onGround) {
        return new GTArmor(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
    }

    public GTArmor setStepAssist(boolean stepAssist) {
        return new GTArmor(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
    }

    public GTArmor setToggleTimer(byte toggleTimer) {
        return new GTArmor(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
    }

    public GTArmor setBurnTimer(short burnTimer) {
        return new GTArmor(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
    }

    public GTArmor setNightVisionTimer(int nightVisionTimer) {
        return new GTArmor(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
    }

    public GTArmor setRunningTimer(byte runningTimer) {
        return new GTArmor(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
    }

    public GTArmor setBoostedJumpTimer(byte boostedJumpTimer) {
        return new GTArmor(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
    }

    public GTArmor setConsumerTicks(byte consumerTicks) {
        return new GTArmor(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
    }

    public Mutable toMutable() {
        return new Mutable(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
    }


    public static class Mutable {
        private boolean enabled;
        private boolean hover;
        private boolean canShare;
        private boolean nightVision;
        private boolean boostedJump;
        private boolean stepAssist;
        private boolean onGround;
        private byte toggleTimer;
        private short burnTimer;
        private int nightVisionTimer;
        private byte runningTimer;
        private byte boostedJumpTimer;
        private byte consumerTicks;

        public GTArmor toImmutable() {
            return new GTArmor(enabled, hover, canShare, nightVision, boostedJump, onGround, stepAssist, toggleTimer, burnTimer, nightVisionTimer, runningTimer, boostedJumpTimer, consumerTicks);
        }

        public Mutable(final boolean enabled, final boolean hover, final boolean canShare, final boolean nightVision, final boolean boostedJump, final boolean stepAssist, final boolean onGround, final byte toggleTimer, final short burnTimer, final int nightVisionTimer, final byte runningTimer, final byte boostedJumpTimer, final byte consumerTicks) {
            this.enabled = enabled;
            this.hover = hover;
            this.canShare = canShare;
            this.nightVision = nightVision;
            this.boostedJump = boostedJump;
            this.stepAssist = stepAssist;
            this.onGround = onGround;
            this.toggleTimer = toggleTimer;
            this.burnTimer = burnTimer;
            this.nightVisionTimer = nightVisionTimer;
            this.runningTimer = runningTimer;
            this.boostedJumpTimer = boostedJumpTimer;
            this.consumerTicks = consumerTicks;
        }

        public boolean enabled() {
            return this.enabled;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public GTArmor.Mutable enabled(final boolean enabled) {
            this.enabled = enabled;
            return this;
        }

        public boolean hover() {
            return this.hover;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public GTArmor.Mutable hover(final boolean hover) {
            this.hover = hover;
            return this;
        }

        public boolean canShare() {
            return this.canShare;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public GTArmor.Mutable canShare(final boolean canShare) {
            this.canShare = canShare;
            return this;
        }

        public boolean nightVision() {
            return this.nightVision;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public GTArmor.Mutable nightVision(final boolean nightVision) {
            this.nightVision = nightVision;
            return this;
        }

        public boolean boostedJump() {
            return this.boostedJump;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public GTArmor.Mutable boostedJump(final boolean boostedJump) {
            this.boostedJump = boostedJump;
            return this;
        }

        public boolean stepAssist() {
            return this.stepAssist;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public GTArmor.Mutable stepAssist(final boolean stepAssist) {
            this.stepAssist = stepAssist;
            return this;
        }

        public boolean onGround() {
            return this.onGround;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public GTArmor.Mutable onGround(final boolean onGround) {
            this.onGround = onGround;
            return this;
        }

        public byte toggleTimer() {
            return this.toggleTimer;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public GTArmor.Mutable toggleTimer(final byte toggleTimer) {
            this.toggleTimer = toggleTimer;
            return this;
        }

        public short burnTimer() {
            return this.burnTimer;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public GTArmor.Mutable burnTimer(final short burnTimer) {
            this.burnTimer = burnTimer;
            return this;
        }

        public int nightVisionTimer() {
            return this.nightVisionTimer;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public GTArmor.Mutable nightVisionTimer(final int nightVisionTimer) {
            this.nightVisionTimer = nightVisionTimer;
            return this;
        }

        public byte runningTimer() {
            return this.runningTimer;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public GTArmor.Mutable runningTimer(final byte runningTimer) {
            this.runningTimer = runningTimer;
            return this;
        }

        public byte boostedJumpTimer() {
            return this.boostedJumpTimer;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public GTArmor.Mutable boostedJumpTimer(final byte boostedJumpTimer) {
            this.boostedJumpTimer = boostedJumpTimer;
            return this;
        }

        public byte consumerTicks() {
            return this.consumerTicks;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public GTArmor.Mutable consumerTicks(final byte consumerTicks) {
            this.consumerTicks = consumerTicks;
            return this;
        }
    }
}
