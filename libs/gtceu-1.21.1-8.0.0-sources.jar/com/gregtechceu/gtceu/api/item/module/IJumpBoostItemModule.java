package com.gregtechceu.gtceu.api.item.module;

public interface IJumpBoostItemModule {

    float getJumpBoost(ModuleContext moduleContext);
}
