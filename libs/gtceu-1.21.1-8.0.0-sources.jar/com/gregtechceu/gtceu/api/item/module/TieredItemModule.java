package com.gregtechceu.gtceu.api.item.module;

import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.capability.GTCapabilityHelper;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import java.util.Locale;

public abstract class TieredItemModule extends ItemModule implements ITieredItemModule {
    private final int tier;
    @Nullable
    private Holder<ItemModule>[] otherTierModules;
    private final ResourceLocation baseLocation;

    public TieredItemModule(ResourceLocation id, int tier) {
        super(id);
        this.tier = tier;
        this.baseLocation = getId().withPath(p -> p.replaceFirst(GTValues.VN[tier].toLowerCase(Locale.ROOT) + "_", ""));
    }

    @Override
    public boolean canApplyTo(ItemStack stack) {
        IModularItem modularItem = GTCapabilityHelper.getModularItem(stack);
        if (modularItem == null) return false;
        for (Holder<ItemModule> module : otherTierModules) {
            if (module == null) continue;
            if (modularItem.getModuleContext(module.value()) != null) return false;
        }
        return super.canApplyTo(stack);
    }

    @Override
    public String getLanguageKey() {
        return baseLocation.toLanguageKey("module");
    }

    @Override
    public String getDescriptionLanguageKey() {
        return baseLocation.toLanguageKey("module", "description");
    }

    @Override
    public Component getDisplayName(ModuleContext moduleContext) {
        return Component.translatable(getLanguageKey(), GTValues.VNF[getTier()]);
    }

    public int getTier() {
        return this.tier;
    }

    @Nullable
    public Holder<ItemModule>[] getOtherTierModules() {
        return this.otherTierModules;
    }

    @ApiStatus.Internal
    public void setOtherTierModules(@Nullable final Holder<ItemModule>[] otherTierModules) {
        this.otherTierModules = otherTierModules;
    }
}
