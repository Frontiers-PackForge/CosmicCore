package com.gregtechceu.gtceu.api.item.module;

import com.gregtechceu.gtceu.common.mui.drawable.BorderDrawable;

import net.minecraft.network.chat.Component;

import brachy.modularui.api.drawable.IDrawable;

public class UniversalItemModuleSlot extends ItemModuleSlot {

    @Override
    public boolean acceptsModule(ItemModule module) {
        return true;
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("gui.gtceu.module_slot.universal");
    }

    @Override
    public IDrawable getSlotTexture() {
        return new BorderDrawable(0xFFFFFFFF, 1);
    }
}
