package com.gregtechceu.gtceu.api.fluids.store;

import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import com.gregtechceu.gtceu.api.data.chemical.material.info.MaterialIconType;
import com.gregtechceu.gtceu.api.fluids.FluidState;
import com.gregtechceu.gtceu.utils.TagUtil;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.material.Fluid;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import java.util.Collection;
import java.util.Map;
import java.util.function.Function;

public final class FluidStorageKey {
    private static final Map<ResourceLocation, FluidStorageKey> keys = new Object2ObjectOpenHashMap<>();
    private final ResourceLocation resourceLocation;
    @Nullable
    private final TagKey<Fluid> extraTag;
    private final MaterialIconType iconType;
    private final Function<Material, String> registryNameFunction;
    private final Function<Material, String> translationKeyFunction;
    private final int hashCode;
    @Nullable
    private final FluidState defaultFluidState;
    private final int registrationPriority;

    public FluidStorageKey(ResourceLocation resourceLocation, @Nullable TagKey<Fluid> extraTag, MaterialIconType iconType, Function<@NotNull Material, @NotNull String> registryNameFunction, Function<@NotNull Material, @NotNull String> translationKeyFunction, @Nullable FluidState defaultFluidState, int registrationPriority) {
        this.resourceLocation = resourceLocation;
        this.extraTag = extraTag;
        this.iconType = iconType;
        this.registryNameFunction = registryNameFunction;
        this.translationKeyFunction = translationKeyFunction;
        this.hashCode = resourceLocation.hashCode();
        this.defaultFluidState = defaultFluidState;
        this.registrationPriority = registrationPriority;
        if (keys.containsKey(resourceLocation)) {
            throw new IllegalArgumentException("Cannot create duplicate keys");
        }
        keys.put(resourceLocation, this);
    }

    public FluidStorageKey(ResourceLocation resourceLocation, String tagKey, MaterialIconType iconType, Function<@NotNull Material, @NotNull String> registryNameFunction, Function<@NotNull Material, @NotNull String> translationKeyFunction, @Nullable FluidState defaultFluidState, int registrationPriority) {
        this(resourceLocation, TagUtil.createFluidTag(tagKey), iconType, registryNameFunction, translationKeyFunction, defaultFluidState, registrationPriority);
    }

    public FluidStorageKey(ResourceLocation resourceLocation, MaterialIconType iconType, Function<@NotNull Material, @NotNull String> registryNameFunction, Function<@NotNull Material, @NotNull String> translationKeyFunction, @Nullable FluidState defaultFluidState, int registrationPriority) {
        this(resourceLocation, (TagKey<Fluid>) null, iconType, registryNameFunction, translationKeyFunction, defaultFluidState, registrationPriority);
    }

    @Nullable
    public static FluidStorageKey getByName(ResourceLocation location) {
        return keys.get(location);
    }

    public static Collection<FluidStorageKey> allKeys() {
        return keys.values();
    }

    /**
     * @param baseName the base name of the fluid
     * @return the registry name to use
     */
    public String getRegistryNameFor(Material baseName) {
        return registryNameFunction.apply(baseName);
    }

    /**
     * @return the translation key for fluids with this key
     */
    public String getTranslationKeyFor(Material material) {
        return this.translationKeyFunction.apply(material);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FluidStorageKey fluidKey = (FluidStorageKey) o;
        return resourceLocation.equals(fluidKey.getResourceLocation());
    }

    @Override
    public int hashCode() {
        return this.hashCode;
    }

    @Override
    public String toString() {
        return "FluidStorageKey{" + resourceLocation + '}';
    }

    public ResourceLocation getResourceLocation() {
        return this.resourceLocation;
    }

    @Nullable
    public TagKey<Fluid> getExtraTag() {
        return this.extraTag;
    }

    public MaterialIconType getIconType() {
        return this.iconType;
    }

    @Nullable
    public FluidState getDefaultFluidState() {
        return this.defaultFluidState;
    }

    public int getRegistrationPriority() {
        return this.registrationPriority;
    }
}
