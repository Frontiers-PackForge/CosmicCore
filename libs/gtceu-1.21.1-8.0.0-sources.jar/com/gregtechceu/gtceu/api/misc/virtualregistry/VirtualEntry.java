package com.gregtechceu.gtceu.api.misc.virtualregistry;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.common.util.INBTSerializable;
import java.util.Locale;

public abstract class VirtualEntry implements INBTSerializable<CompoundTag> {
    public static final String DEFAULT_COLOR = "FFFFFFFF";
    protected static final String COLOR_KEY = "color";
    protected static final String DESC_KEY = "description";
    private String description = "";
    private int color = -1;
    private String colorStr = DEFAULT_COLOR;

    public abstract EntryTypes<? extends VirtualEntry> getType();

    public void setColor(String color) {
        this.color = parseColor(color);
        this.colorStr = color.toUpperCase(Locale.ROOT);
    }

    public void setColor(int color) {
        this.color = color;
        this.colorStr = Integer.toHexString(color).toUpperCase(Locale.ROOT);
    }

    public static int parseColor(String colorString) {
        if (colorString.length() < 8) {
            throw new IllegalArgumentException("Invalid color string: " + colorString);
        }
        int red = Integer.parseInt(colorString.substring(0, 2), 16);
        int green = Integer.parseInt(colorString.substring(2, 4), 16);
        int blue = Integer.parseInt(colorString.substring(4, 6), 16);
        int alpha = Integer.parseInt(colorString.substring(6, 8), 16);
        return (alpha << 24) | (red << 16) | (green << 8) | blue;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof VirtualEntry other)) return false;
        return this.getType() == other.getType() && this.color == other.color && this.description.equals(other.description);
    }

    @Override
    public CompoundTag serializeNBT(HolderLookup.Provider registries) {
        var tag = new CompoundTag();
        tag.putString(COLOR_KEY, this.colorStr);
        if (!description.isEmpty()) tag.putString(DESC_KEY, this.description);
        return tag;
    }

    @Override
    public void deserializeNBT(HolderLookup.Provider registries, CompoundTag nbt) {
        setColor(nbt.getString(COLOR_KEY));
        if (nbt.contains(DESC_KEY)) this.description = nbt.getString(DESC_KEY);
    }

    public boolean canRemove() {
        return this.description.isBlank();
    }

    public String getDescription() {
        return this.description;
    }

    public String getColorStr() {
        return this.colorStr;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public VirtualEntry setDescription(final String description) {
        this.description = description;
        return this;
    }

    public int getColor() {
        return this.color;
    }
}
