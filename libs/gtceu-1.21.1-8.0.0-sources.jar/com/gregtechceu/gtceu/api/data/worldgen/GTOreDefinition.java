package com.gregtechceu.gtceu.api.data.worldgen;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.data.worldgen.generator.IndicatorGenerator;
import com.gregtechceu.gtceu.api.data.worldgen.generator.VeinGenerator;
import com.gregtechceu.gtceu.api.data.worldgen.generator.indicators.SurfaceIndicatorGenerator;
import com.gregtechceu.gtceu.api.data.worldgen.generator.veins.*;
import com.gregtechceu.gtceu.api.registry.GTRegistries;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.HolderSet;
import net.minecraft.core.RegistryCodecs;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.RegistryFixedCodec;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.util.valueproviders.ConstantInt;
import net.minecraft.util.valueproviders.IntProvider;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.levelgen.VerticalAnchor;
import net.minecraft.world.level.levelgen.placement.HeightRangePlacement;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.latvian.mods.rhino.util.HideFromJS;
import it.unimi.dsi.fastutil.ints.IntIntPair;
import lombok.experimental.Tolerate;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Supplier;

@SuppressWarnings("UnusedReturnValue")
public class GTOreDefinition {
    // spotless:off
    public static final Codec<GTOreDefinition> DIRECT_CODEC = RecordCodecBuilder.create(instance -> instance.group(IntProvider.NON_NEGATIVE_CODEC.fieldOf("cluster_size").forGetter(GTOreDefinition::clusterSize), Codec.floatRange(0.0F, 1.0F).fieldOf("density").forGetter(GTOreDefinition::density), Codec.INT.fieldOf("weight").forGetter(GTOreDefinition::weight), IWorldGenLayer.CODEC.fieldOf("layer").forGetter(GTOreDefinition::layer), ResourceKey.codec(Registries.DIMENSION).listOf().fieldOf("dimension_filter").forGetter(ft -> new ArrayList<>(ft.dimensionFilter)), HeightRangePlacement.CODEC.fieldOf("height_range").forGetter(GTOreDefinition::heightRange), Codec.floatRange(0.0F, 1.0F).fieldOf("discard_chance_on_air_exposure").forGetter(GTOreDefinition::discardChanceOnAirExposure), RegistryCodecs.homogeneousList(Registries.BIOME).lenientOptionalFieldOf("biomes", HolderSet.empty()).forGetter(GTOreDefinition::biomes), BiomeWeightModifier.CODEC.optionalFieldOf("weight_modifier", BiomeWeightModifier.EMPTY).forGetter(ext -> ext.biomeWeightModifier), VeinGenerator.DIRECT_CODEC.fieldOf("generator").forGetter(ft -> ft.veinGenerator), Codec.list(IndicatorGenerator.DIRECT_CODEC).fieldOf("indicators").forGetter(ft -> ft.indicatorGenerators)).apply(instance, GTOreDefinition::new));
    public static final Codec<Holder<GTOreDefinition>> CODEC = RegistryFixedCodec.create(GTRegistries.ORE_VEIN_REGISTRY);
    public static final StreamCodec<RegistryFriendlyByteBuf, Holder<GTOreDefinition>> STREAM_CODEC = ByteBufCodecs.holderRegistry(GTRegistries.ORE_VEIN_REGISTRY);
    // spotless:on
    private final InferredProperties inferredProperties = new InferredProperties();
    private IntProvider clusterSize;
    private float density;
    private int weight;
    private IWorldGenLayer layer;
    private Set<ResourceKey<Level>> dimensionFilter;
    private HeightRangePlacement heightRange;
    private float discardChanceOnAirExposure;
    private HolderSet<Biome> biomes;
    private BiomeWeightModifier biomeWeightModifier;
    private VeinGenerator veinGenerator;
    private List<IndicatorGenerator> indicatorGenerators;
    @ApiStatus.Internal
    @Nullable
    private HolderGetter<Biome> biomeLookup;

    public GTOreDefinition(GTOreDefinition other) {
        this(other.clusterSize, other.density, other.weight, other.layer, Set.copyOf(other.dimensionFilter), other.heightRange, other.discardChanceOnAirExposure, other.biomes, other.biomeWeightModifier, other.veinGenerator, List.copyOf(other.indicatorGenerators), other.biomeLookup);
    }

    public GTOreDefinition(IntProvider clusterSize, float density, int weight, IWorldGenLayer layer, List<ResourceKey<Level>> dimensionFilter, HeightRangePlacement heightRange, float discardChanceOnAirExposure, HolderSet<Biome> biomes, BiomeWeightModifier biomeWeightModifier, @Nullable VeinGenerator veinGenerator, @Nullable List<IndicatorGenerator> indicatorGenerators) {
        this(clusterSize, density, weight, layer, new HashSet<>(dimensionFilter), heightRange, discardChanceOnAirExposure, biomes, biomeWeightModifier, veinGenerator, indicatorGenerators, null);
    }

    public GTOreDefinition(IntProvider clusterSize, float density, int weight, IWorldGenLayer layer, Set<ResourceKey<Level>> dimensionFilter, HeightRangePlacement heightRange, float discardChanceOnAirExposure, HolderSet<Biome> biomes, BiomeWeightModifier biomeWeightModifier, @Nullable VeinGenerator veinGenerator, @Nullable List<IndicatorGenerator> indicatorGenerators, @Nullable HolderGetter<Biome> biomeLookup) {
        this.clusterSize = clusterSize;
        this.density = density;
        this.weight = weight;
        this.layer = layer;
        this.dimensionFilter = dimensionFilter;
        this.heightRange = heightRange;
        this.discardChanceOnAirExposure = discardChanceOnAirExposure;
        this.biomes = biomes;
        this.biomeWeightModifier = biomeWeightModifier;
        this.veinGenerator = veinGenerator;
        this.indicatorGenerators = Objects.requireNonNullElseGet(indicatorGenerators, ArrayList::new);
        this.biomeLookup = biomeLookup;
    }

    public boolean isForBiome(Holder<Biome> biome) {
        if (biomes == null) return true;
        return biomes.size() == 0 || biomes.contains(biome);
    }

    public int weightForBiome(Holder<Biome> biome) {
        return weight + biomeWeightModifier.applyAsInt(biome);
    }

    public GTOreDefinition clusterSize(IntProvider clusterSize) {
        this.clusterSize = clusterSize;
        return this;
    }

    public GTOreDefinition clusterSize(int clusterSize) {
        this.clusterSize = ConstantInt.of(clusterSize);
        return this;
    }

    public GTOreDefinition density(float density) {
        this.density = density;
        return this;
    }

    public GTOreDefinition weight(int weight) {
        this.weight = weight;
        return this;
    }

    public GTOreDefinition layer(IWorldGenLayer layer) {
        this.layer = layer;
        if (this.dimensionFilter == null || this.dimensionFilter.isEmpty()) {
            dimensions(layer.getLevels());
        }
        return this;
    }

    public GTOreDefinition dimensions(Set<ResourceKey<Level>> dimensions) {
        this.dimensionFilter = dimensions;
        return this;
    }

    @HideFromJS
    public GTOreDefinition biomes(TagKey<Biome> biomes) {
        if (biomeLookup == null) {
            GTRegistries.builtinRegistry().registry(GTRegistries.ORE_VEIN_REGISTRY).map(reg -> reg.getKey(this)).ifPresentOrElse(id -> {
                GTCEu.LOGGER.error("Tried to modify ore vein `{}`\'s biomes after registry has been frozen!", id);
            }, () -> {
                GTCEu.LOGGER.error("Tried to modify an ore vein\'s biomes after registry has been frozen!");
            });
            return this;
        }
        this.biomes = biomeLookup.getOrThrow(biomes);
        return this;
    }

    public GTOreDefinition biomes(HolderSet<Biome> biomes) {
        this.biomes = Objects.requireNonNullElseGet(biomes, HolderSet::empty);
        return this;
    }

    public GTOreDefinition heightRangeUniform(int min, int max) {
        heightRange(HeightRangePlacement.uniform(VerticalAnchor.absolute(min), VerticalAnchor.absolute(max)));
        inferredProperties.heightRange = IntIntPair.of(min, max);
        return this;
    }

    public GTOreDefinition heightRangeTriangle(int min, int max) {
        heightRange(HeightRangePlacement.triangle(VerticalAnchor.absolute(min), VerticalAnchor.absolute(max)));
        inferredProperties.heightRange = IntIntPair.of(min, max);
        return this;
    }

    public GTOreDefinition standardVeinGenerator(Consumer<StandardVeinGenerator> config) {
        var veinGenerator = new StandardVeinGenerator();
        config.accept(veinGenerator);
        this.veinGenerator = veinGenerator;
        return this;
    }

    public GTOreDefinition layeredVeinGenerator(Consumer<LayeredVeinGenerator> config) {
        var veinGenerator = new LayeredVeinGenerator();
        config.accept(veinGenerator);
        this.veinGenerator = veinGenerator;
        return this;
    }

    public GTOreDefinition geodeVeinGenerator(Consumer<GeodeVeinGenerator> config) {
        var veinGenerator = new GeodeVeinGenerator();
        config.accept(veinGenerator);
        this.veinGenerator = veinGenerator;
        return this;
    }

    public GTOreDefinition dikeVeinGenerator(Consumer<DikeVeinGenerator> config) {
        var veinGenerator = new DikeVeinGenerator();
        if (inferredProperties.heightRange != null) {
            veinGenerator.minYLevel(inferredProperties.heightRange.firstInt());
            veinGenerator.maxYLevel(inferredProperties.heightRange.secondInt());
        }
        config.accept(veinGenerator);
        this.veinGenerator = veinGenerator;
        return this;
    }

    public GTOreDefinition veinedVeinGenerator(Consumer<VeinedVeinGenerator> config) {
        var veinGenerator = new VeinedVeinGenerator();
        if (inferredProperties.heightRange != null) {
            veinGenerator.minYLevel(inferredProperties.heightRange.firstInt());
            veinGenerator.maxYLevel(inferredProperties.heightRange.secondInt());
        }
        config.accept(veinGenerator);
        this.veinGenerator = veinGenerator;
        return this;
    }

    public GTOreDefinition classicVeinGenerator(Consumer<ClassicVeinGenerator> config) {
        var veinGenerator = new ClassicVeinGenerator();
        config.accept(veinGenerator);
        this.veinGenerator = veinGenerator;
        return this;
    }

    public GTOreDefinition cuboidVeinGenerator(Consumer<CuboidVeinGenerator> config) {
        var veinGenerator = new CuboidVeinGenerator();
        if (inferredProperties.heightRange != null) {
            veinGenerator.minY(inferredProperties.heightRange.firstInt());
            veinGenerator.maxY(inferredProperties.heightRange.secondInt());
        }
        config.accept(veinGenerator);
        this.veinGenerator = veinGenerator;
        return this;
    }

    @Tolerate
    @Nullable
    public VeinGenerator veinGenerator(ResourceLocation id) {
        if (veinGenerator == null) {
            // noinspection DataFlowIssue
            veinGenerator = WorldGeneratorUtils.VEIN_GENERATOR_FUNCTIONS.containsKey(id) ? WorldGeneratorUtils.VEIN_GENERATOR_FUNCTIONS.get(id).get() : null;
        }
        return veinGenerator;
    }

    public GTOreDefinition surfaceIndicatorGenerator(Consumer<SurfaceIndicatorGenerator> config) {
        config.accept(getOrCreateIndicatorGenerator(SurfaceIndicatorGenerator.class, SurfaceIndicatorGenerator::new));
        return this;
    }

    @SuppressWarnings("SameParameterValue")
    private <T extends IndicatorGenerator> T getOrCreateIndicatorGenerator(Class<T> indicatorClass, Supplier<T> constructor) {
        var existingGenerator = indicatorGenerators.stream().filter(indicatorClass::isInstance).map(indicatorClass::cast).findFirst().orElse(null);
        if (existingGenerator != null) return existingGenerator;
        var generator = constructor.get();
        indicatorGenerators.add(generator);
        return generator;
    }

    public boolean canGenerate() {
        if (this.veinGenerator() instanceof NoopVeinGenerator) {
            return false;
        }
        return this.weight() > 0 || !this.biomeWeightModifier().isEmpty();
    }


    private static class InferredProperties {
        public IntIntPair heightRange = null;
    }

    public IntProvider clusterSize() {
        return this.clusterSize;
    }

    public float density() {
        return this.density;
    }

    public int weight() {
        return this.weight;
    }

    public IWorldGenLayer layer() {
        return this.layer;
    }

    public Set<ResourceKey<Level>> dimensionFilter() {
        return this.dimensionFilter;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public GTOreDefinition dimensionFilter(final Set<ResourceKey<Level>> dimensionFilter) {
        this.dimensionFilter = dimensionFilter;
        return this;
    }

    public HeightRangePlacement heightRange() {
        return this.heightRange;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public GTOreDefinition heightRange(final HeightRangePlacement heightRange) {
        this.heightRange = heightRange;
        return this;
    }

    public float discardChanceOnAirExposure() {
        return this.discardChanceOnAirExposure;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public GTOreDefinition discardChanceOnAirExposure(final float discardChanceOnAirExposure) {
        this.discardChanceOnAirExposure = discardChanceOnAirExposure;
        return this;
    }

    public HolderSet<Biome> biomes() {
        return this.biomes;
    }

    public BiomeWeightModifier biomeWeightModifier() {
        return this.biomeWeightModifier;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public GTOreDefinition biomeWeightModifier(final BiomeWeightModifier biomeWeightModifier) {
        this.biomeWeightModifier = biomeWeightModifier;
        return this;
    }

    public VeinGenerator veinGenerator() {
        return this.veinGenerator;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public GTOreDefinition veinGenerator(final VeinGenerator veinGenerator) {
        this.veinGenerator = veinGenerator;
        return this;
    }

    public List<IndicatorGenerator> indicatorGenerators() {
        return this.indicatorGenerators;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public GTOreDefinition indicatorGenerators(final List<IndicatorGenerator> indicatorGenerators) {
        this.indicatorGenerators = indicatorGenerators;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public GTOreDefinition biomeLookup(@Nullable final HolderGetter<Biome> biomeLookup) {
        this.biomeLookup = biomeLookup;
        return this;
    }
}
