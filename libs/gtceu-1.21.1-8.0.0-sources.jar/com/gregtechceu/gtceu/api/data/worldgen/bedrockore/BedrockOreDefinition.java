package com.gregtechceu.gtceu.api.data.worldgen.bedrockore;

import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import com.gregtechceu.gtceu.api.data.worldgen.BiomeWeightModifier;
import com.gregtechceu.gtceu.api.registry.GTRegistries;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.RegistryFixedCodec;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.valueproviders.IntProvider;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import lombok.experimental.Tolerate;
import java.util.*;

public class BedrockOreDefinition {
    // spotless:off
    public static final Codec<BedrockOreDefinition> DIRECT_CODEC = RecordCodecBuilder.create(instance -> instance.group(Codec.INT.fieldOf("weight").forGetter(BedrockOreDefinition::weight), Codec.INT.fieldOf("size").forGetter(BedrockOreDefinition::size), IntProvider.POSITIVE_CODEC.fieldOf("yield").forGetter(BedrockOreDefinition::yield), Codec.INT.fieldOf("depletion_amount").forGetter(BedrockOreDefinition::depletionAmount), ExtraCodecs.intRange(0, 100).fieldOf("depletion_chance").forGetter(BedrockOreDefinition::depletionChance), Codec.INT.fieldOf("depleted_yield").forGetter(BedrockOreDefinition::depletedYield), WeightedMaterial.CODEC.listOf().fieldOf("materials").forGetter(BedrockOreDefinition::materials), BiomeWeightModifier.CODEC.optionalFieldOf("weight_modifier", BiomeWeightModifier.EMPTY).forGetter(BedrockOreDefinition::biomeWeightModifier), ResourceKey.codec(Registries.DIMENSION).listOf().fieldOf("dimension_filter").forGetter(ft -> new ArrayList<>(ft.dimensionFilter))).apply(instance, BedrockOreDefinition::new));
    public static final Codec<Holder<BedrockOreDefinition>> CODEC = RegistryFixedCodec.create(GTRegistries.BEDROCK_ORE_REGISTRY);
    // spotless:on
    private int weight; // weight value for determining which vein will appear
    private int size; // size in chunks
    private IntProvider yield;// the [minimum, maximum] yields
    private int depletionAmount; // amount of ore the vein gets drained by
    private int depletionChance; // the chance [0, 100] that the vein will deplete by 1
    private int depletedYield; // yield after the vein is depleted
    private List<WeightedMaterial> materials; // the ores which the vein contains
    private BiomeWeightModifier biomeWeightModifier; // weighting of biomes
    public Set<ResourceKey<Level>> dimensionFilter; // filtering of dimensions

    public BedrockOreDefinition(int weight, int size, IntProvider yield, int depletionAmount, int depletionChance, int depletedYield, List<WeightedMaterial> materials, BiomeWeightModifier biomeWeightModifier, List<ResourceKey<Level>> dimensionFilter) {
        this(weight, size, yield, depletionAmount, depletionChance, depletedYield, materials, biomeWeightModifier, new HashSet<>(dimensionFilter));
    }

    public BedrockOreDefinition(int weight, int size, IntProvider yield, int depletionAmount, int depletionChance, int depletedYield, List<WeightedMaterial> materials, BiomeWeightModifier biomeWeightModifier, Set<ResourceKey<Level>> dimensionFilter) {
        this.weight = weight;
        this.size = size;
        this.yield = yield;
        this.depletionAmount = depletionAmount;
        this.depletionChance = depletionChance;
        this.depletedYield = depletedYield;
        this.materials = materials;
        this.biomeWeightModifier = biomeWeightModifier;
        this.dimensionFilter = dimensionFilter;
    }

    @Tolerate
    public void biomeWeightModifier(List<BiomeWeightModifier> modifiers) {
        this.biomeWeightModifier = BiomeWeightModifier.fromList(modifiers);
    }

    public IntList getAllChances() {
        return IntArrayList.toList(materials().stream().mapToInt(WeightedMaterial::weight));
    }

    public List<Material> getAllMaterials() {
        return materials().stream().map(WeightedMaterial::material).toList();
    }

    public boolean canGenerate() {
        return this.weight() > 0 || !this.biomeWeightModifier().isEmpty();
    }

    public List<BiomeWeightModifier> getOriginalModifiers() {
        if (this.biomeWeightModifier instanceof BiomeWeightModifier.FromList list) {
            return list.getOriginalModifiers();
        } else {
            return Collections.singletonList(this.biomeWeightModifier);
        }
    }

    public static Builder builder(HolderGetter<Biome> biomeLookup) {
        return new Builder(biomeLookup);
    }

    public Builder asBuilder(HolderGetter<Biome> biomeLookup) {
        Builder builder = builder(biomeLookup);
        builder.weight(this.weight);
        builder.size(this.size);
        builder.yield(this.yield);
        builder.depletionAmount(this.depletionAmount).depletionChance(this.depletionChance);
        builder.depletedYield(this.depletedYield);
        builder.materials(this.materials);
        builder.dimensions(this.dimensionFilter);
        builder.biomes(this.getOriginalModifiers());
        return builder;
    }


    public static class Builder {
        private final HolderGetter<Biome> biomeLookup;
        private int weight; // weight value for determining which vein will appear
        private int size; // size of the vein, in chunks.
        private IntProvider yield;// the [minimum, maximum) yields
        private int depletionAmount; // amount of fluid the vein gets drained by
        private int depletionChance = 1; // the chance [0, 100] that the vein will deplete by 1
        private int depletedYield; // yield after the vein is depleted
        private List<WeightedMaterial> materials = new ArrayList<>(); // the ores which the vein contains
        private Set<ResourceKey<Level>> dimensions = Collections.emptySet();
        private final List<BiomeWeightModifier> biomes = new LinkedList<>();

        private Builder(HolderGetter<Biome> biomeLookup) {
            this.biomeLookup = biomeLookup;
        }

        public Builder copy() {
            var copied = new Builder(biomeLookup);
            copied.weight = weight;
            copied.yield = yield;
            copied.depletionAmount = depletionAmount;
            copied.depletionChance = depletionChance;
            copied.depletedYield = depletedYield;
            copied.materials = materials;
            return copied;
        }

        public Builder material(Material material, int amount) {
            this.materials.add(new WeightedMaterial(material, amount));
            return this;
        }

        public Builder yield(int min, int max) {
            return this.yield(UniformInt.of(min, max));
        }

        public Builder biomes(int weight, TagKey<Biome> biomes) {
            this.biomes.add(new BiomeWeightModifier(biomeLookup.getOrThrow(biomes), weight));
            return this;
        }

        @SafeVarargs
        public final Builder biomes(int weight, ResourceKey<Biome>... biomes) {
            this.biomes.add(new BiomeWeightModifier(HolderSet.direct(biomeLookup::getOrThrow, biomes), weight));
            return this;
        }

        public Builder biomes(int weight, HolderSet<Biome> biomes) {
            this.biomes.add(new BiomeWeightModifier(biomes, weight));
            return this;
        }

        public Builder biomes(List<BiomeWeightModifier> modifiers) {
            this.biomes.addAll(modifiers);
            return this;
        }

        public BedrockOreDefinition build() {
            return new BedrockOreDefinition(weight, size, yield, depletionAmount, depletionChance, depletedYield, materials, BiomeWeightModifier.fromList(biomes), dimensions);
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockOreDefinition.Builder weight(final int weight) {
            this.weight = weight;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockOreDefinition.Builder size(final int size) {
            this.size = size;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockOreDefinition.Builder yield(final IntProvider yield) {
            this.yield = yield;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockOreDefinition.Builder depletionAmount(final int depletionAmount) {
            this.depletionAmount = depletionAmount;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockOreDefinition.Builder depletionChance(final int depletionChance) {
            this.depletionChance = depletionChance;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockOreDefinition.Builder depletedYield(final int depletedYield) {
            this.depletedYield = depletedYield;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockOreDefinition.Builder materials(final List<WeightedMaterial> materials) {
            this.materials = materials;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockOreDefinition.Builder dimensions(final Set<ResourceKey<Level>> dimensions) {
            this.dimensions = dimensions;
            return this;
        }
    }

    public int weight() {
        return this.weight;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinition weight(final int weight) {
        this.weight = weight;
        return this;
    }

    public int size() {
        return this.size;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinition size(final int size) {
        this.size = size;
        return this;
    }

    public IntProvider yield() {
        return this.yield;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinition yield(final IntProvider yield) {
        this.yield = yield;
        return this;
    }

    public int depletionAmount() {
        return this.depletionAmount;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinition depletionAmount(final int depletionAmount) {
        this.depletionAmount = depletionAmount;
        return this;
    }

    public int depletionChance() {
        return this.depletionChance;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinition depletionChance(final int depletionChance) {
        this.depletionChance = depletionChance;
        return this;
    }

    public int depletedYield() {
        return this.depletedYield;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinition depletedYield(final int depletedYield) {
        this.depletedYield = depletedYield;
        return this;
    }

    public List<WeightedMaterial> materials() {
        return this.materials;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinition materials(final List<WeightedMaterial> materials) {
        this.materials = materials;
        return this;
    }

    public BiomeWeightModifier biomeWeightModifier() {
        return this.biomeWeightModifier;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinition biomeWeightModifier(final BiomeWeightModifier biomeWeightModifier) {
        this.biomeWeightModifier = biomeWeightModifier;
        return this;
    }

    public Set<ResourceKey<Level>> dimensionFilter() {
        return this.dimensionFilter;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public BedrockOreDefinition dimensionFilter(final Set<ResourceKey<Level>> dimensionFilter) {
        this.dimensionFilter = dimensionFilter;
        return this;
    }
}
