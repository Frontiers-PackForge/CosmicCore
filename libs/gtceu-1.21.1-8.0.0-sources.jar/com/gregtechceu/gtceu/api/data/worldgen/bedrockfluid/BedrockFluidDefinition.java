package com.gregtechceu.gtceu.api.data.worldgen.bedrockfluid;

import com.gregtechceu.gtceu.api.data.worldgen.BiomeWeightModifier;
import com.gregtechceu.gtceu.api.registry.GTRegistries;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.RegistryFixedCodec;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.material.Fluid;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import lombok.experimental.Tolerate;
import java.util.*;

public class BedrockFluidDefinition {
    // spotless:off
    public static final MapCodec<Pair<Integer, Integer>> YIELD = Codec.mapPair(Codec.INT.fieldOf("min"), Codec.INT.fieldOf("max"));
    public static final Codec<BedrockFluidDefinition> DIRECT_CODEC = RecordCodecBuilder.create(instance -> instance.group(Codec.INT.fieldOf("weight").forGetter(BedrockFluidDefinition::getWeight), YIELD.fieldOf("yield").forGetter(ft -> Pair.of(ft.minimumYield, ft.maximumYield)), Codec.INT.fieldOf("depletion_amount").forGetter(BedrockFluidDefinition::getDepletionAmount), Codec.INT.fieldOf("depletion_chance").forGetter(BedrockFluidDefinition::getDepletionChance), Codec.INT.fieldOf("depleted_yield").forGetter(BedrockFluidDefinition::getDepletedYield), BuiltInRegistries.FLUID.byNameCodec().fieldOf("fluid").forGetter(BedrockFluidDefinition::getStoredFluid), BiomeWeightModifier.CODEC.optionalFieldOf("weight_modifier", BiomeWeightModifier.EMPTY).forGetter(BedrockFluidDefinition::getBiomeWeightModifier), ResourceKey.codec(Registries.DIMENSION).listOf().fieldOf("dimension_filter").forGetter(ft -> new ArrayList<>(ft.dimensionFilter))).apply(instance, BedrockFluidDefinition::new));
    public static final Codec<Holder<BedrockFluidDefinition>> CODEC = RegistryFixedCodec.create(GTRegistries.BEDROCK_FLUID_REGISTRY);
    // spotless:on
    private int weight; // weight value for determining which vein will appear
    private int minimumYield;
    private int maximumYield;// the [minimum, maximum) yields
    private int depletionAmount; // amount of fluid the vein gets drained by
    private int depletionChance; // the chance [0, 100] that the vein will deplete by 1
    private int depletedYield; // yield after the vein is depleted
    private Fluid storedFluid; // the fluid which the vein contains
    private BiomeWeightModifier biomeWeightModifier; // weighting of biomes
    public Set<ResourceKey<Level>> dimensionFilter; // filtering of dimensions

    private BedrockFluidDefinition(int weight, Pair<Integer, Integer> yield, int depletionAmount, int depletionChance, int depletedYield, Fluid storedFluid, BiomeWeightModifier modifier, List<ResourceKey<Level>> dimensionFilter) {
        this(weight, yield.getFirst(), yield.getSecond(), depletionAmount, depletionChance, depletedYield, storedFluid, modifier, new HashSet<>(dimensionFilter));
    }

    public BedrockFluidDefinition(int weight, int minimumYield, int maximumYield, int depletionAmount, int depletionChance, int depletedYield, Fluid storedFluid, BiomeWeightModifier modifier, Set<ResourceKey<Level>> dimensionFilter) {
        this.weight = weight;
        this.minimumYield = minimumYield;
        this.maximumYield = maximumYield;
        this.depletionAmount = depletionAmount;
        this.depletionChance = depletionChance;
        this.depletedYield = depletedYield;
        this.storedFluid = storedFluid;
        this.biomeWeightModifier = modifier;
        this.dimensionFilter = dimensionFilter;
    }

    @Tolerate
    public void setBiomeWeightModifier(List<BiomeWeightModifier> modifiers) {
        this.biomeWeightModifier = BiomeWeightModifier.fromList(modifiers);
    }

    public boolean canGenerate() {
        return this.getWeight() > 0 || !this.getBiomeWeightModifier().isEmpty();
    }

    public List<BiomeWeightModifier> getOriginalModifiers() {
        if (this.biomeWeightModifier instanceof BiomeWeightModifier.FromList list) {
            return list.getOriginalModifiers();
        } else {
            return Collections.singletonList(this.biomeWeightModifier);
        }
    }

    public static Builder builder(HolderGetter<Biome> biomeLookup) {
        return new Builder(biomeLookup);
    }

    public Builder asBuilder(HolderGetter<Biome> biomeLookup) {
        Builder builder = builder(biomeLookup);
        builder.weight(this.weight);
        builder.minimumYield(this.minimumYield).maximumYield(this.maximumYield);
        builder.depletionAmount(this.depletionAmount).depletionChance(this.depletionChance);
        builder.depletedYield(this.depletedYield);
        builder.fluid(this.storedFluid);
        builder.dimensions(this.dimensionFilter);
        builder.biomes(this.getOriginalModifiers());
        return builder;
    }


    public static class Builder {
        private int weight; // weight value for determining which vein will appear
        private int minimumYield;
        private int maximumYield;// the [minimum, maximum) yields
        private int depletionAmount; // amount of fluid the vein gets drained by
        private int depletionChance = 1; // the chance [0, 100] that the vein will deplete by 1
        private int depletedYield; // yield after the vein is depleted
        private Fluid fluid; // the fluid which the vein contains
        private Set<ResourceKey<Level>> dimensions = Collections.emptySet();
        private final List<BiomeWeightModifier> biomes = new LinkedList<>();
        private final HolderGetter<Biome> biomeLookup;

        private Builder(HolderGetter<Biome> biomeLookup) {
            this.biomeLookup = biomeLookup;
        }

        public Builder yield(int min, int max) {
            return minimumYield(min).maximumYield(max);
        }

        public Builder biomes(int weight, TagKey<Biome> biomes) {
            this.biomes.add(new BiomeWeightModifier(biomeLookup.getOrThrow(biomes), weight));
            return this;
        }

        @SafeVarargs
        public final Builder biomes(int weight, ResourceKey<Biome>... biomes) {
            this.biomes.add(new BiomeWeightModifier(HolderSet.direct(biomeLookup::getOrThrow, biomes), weight));
            return this;
        }

        public Builder biomes(int weight, HolderSet<Biome> biomes) {
            this.biomes.add(new BiomeWeightModifier(biomes, weight));
            return this;
        }

        public Builder biomes(List<BiomeWeightModifier> modifiers) {
            this.biomes.addAll(modifiers);
            return this;
        }

        public BedrockFluidDefinition build() {
            return new BedrockFluidDefinition(weight, minimumYield, maximumYield, depletionAmount, depletionChance, depletedYield, fluid, BiomeWeightModifier.fromList(biomes), dimensions);
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockFluidDefinition.Builder weight(final int weight) {
            this.weight = weight;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockFluidDefinition.Builder minimumYield(final int minimumYield) {
            this.minimumYield = minimumYield;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockFluidDefinition.Builder maximumYield(final int maximumYield) {
            this.maximumYield = maximumYield;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockFluidDefinition.Builder depletionAmount(final int depletionAmount) {
            this.depletionAmount = depletionAmount;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockFluidDefinition.Builder depletionChance(final int depletionChance) {
            this.depletionChance = depletionChance;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockFluidDefinition.Builder depletedYield(final int depletedYield) {
            this.depletedYield = depletedYield;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockFluidDefinition.Builder fluid(final Fluid fluid) {
            this.fluid = fluid;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public BedrockFluidDefinition.Builder dimensions(final Set<ResourceKey<Level>> dimensions) {
            this.dimensions = dimensions;
            return this;
        }
    }

    public int getWeight() {
        return this.weight;
    }

    public void setWeight(final int weight) {
        this.weight = weight;
    }

    public int getMinimumYield() {
        return this.minimumYield;
    }

    public int getMaximumYield() {
        return this.maximumYield;
    }

    public void setMinimumYield(final int minimumYield) {
        this.minimumYield = minimumYield;
    }

    public void setMaximumYield(final int maximumYield) {
        this.maximumYield = maximumYield;
    }

    public int getDepletionAmount() {
        return this.depletionAmount;
    }

    public void setDepletionAmount(final int depletionAmount) {
        this.depletionAmount = depletionAmount;
    }

    public int getDepletionChance() {
        return this.depletionChance;
    }

    public void setDepletionChance(final int depletionChance) {
        this.depletionChance = depletionChance;
    }

    public int getDepletedYield() {
        return this.depletedYield;
    }

    public void setDepletedYield(final int depletedYield) {
        this.depletedYield = depletedYield;
    }

    public Fluid getStoredFluid() {
        return this.storedFluid;
    }

    public void setStoredFluid(final Fluid storedFluid) {
        this.storedFluid = storedFluid;
    }

    public BiomeWeightModifier getBiomeWeightModifier() {
        return this.biomeWeightModifier;
    }

    public void setBiomeWeightModifier(final BiomeWeightModifier biomeWeightModifier) {
        this.biomeWeightModifier = biomeWeightModifier;
    }

    public Set<ResourceKey<Level>> getDimensionFilter() {
        return this.dimensionFilter;
    }

    public void setDimensionFilter(final Set<ResourceKey<Level>> dimensionFilter) {
        this.dimensionFilter = dimensionFilter;
    }
}
