package com.gregtechceu.gtceu.api.data.chemical.material.properties;

import com.gregtechceu.gtceu.data.recipe.misc.alloyblast.AlloyBlastRecipeProducer;
import org.jetbrains.annotations.NotNull;

public class AlloyBlastProperty implements IMaterialProperty {
    @NotNull
    private AlloyBlastRecipeProducer recipeProducer = AlloyBlastRecipeProducer.DEFAULT_PRODUCER;

    public AlloyBlastProperty() {
    }

    @Override
    public void verifyProperty(MaterialProperties materialProperties) {
        materialProperties.ensureSet(PropertyKey.BLAST);
        materialProperties.ensureSet(PropertyKey.FLUID);
    }

    @NotNull
    public AlloyBlastRecipeProducer getRecipeProducer() {
        return this.recipeProducer;
    }

    public void setRecipeProducer(@NotNull final AlloyBlastRecipeProducer recipeProducer) {
        if (recipeProducer == null) {
            throw new NullPointerException("recipeProducer is marked non-null but is null");
        }
        this.recipeProducer = recipeProducer;
    }
}
