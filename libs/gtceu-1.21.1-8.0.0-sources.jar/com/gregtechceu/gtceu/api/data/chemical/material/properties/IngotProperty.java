package com.gregtechceu.gtceu.api.data.chemical.material.properties;

import com.gregtechceu.gtceu.api.data.chemical.material.Material;
import org.jetbrains.annotations.Nullable;

public class IngotProperty implements IMaterialProperty {
    /**
     * Specifies a material into which this material parts turn when heated.<br>
     * If null, material remains the same.
     */
    @Nullable
    private Material smeltingInto = null;
    /**
     * Specifies a material into which this material parts turn when heated in arc furnace.<br>
     * If null, material remains the same.
     */
    @Nullable
    private Material arcSmeltingInto = null;
    /**
     * Specifies a Material into which this Material Macerates into.<br>
     * If null, material remains the same.
     */
    @Nullable
    private Material macerateInto = null;
    /**
     * Material which obtained when this material is polarized.<br>
     * If null, polarization recipes not generated.
     */
    @Nullable
    private Material magneticMaterial = null;

    @Override
    public void verifyProperty(MaterialProperties properties) {
        properties.ensureSet(PropertyKey.DUST, true);
        if (properties.hasProperty(PropertyKey.GEM)) {
            throw new IllegalStateException("Material " + properties.getMaterial() + " has both Ingot and Gem Property, which is not allowed!");
        }
        if (smeltingInto != null) smeltingInto.getProperties().ensureSet(PropertyKey.INGOT, true);
        if (arcSmeltingInto != null) arcSmeltingInto.getProperties().ensureSet(PropertyKey.INGOT, true);
        if (macerateInto != null) macerateInto.getProperties().ensureSet(PropertyKey.INGOT, true);
        if (magneticMaterial != null) magneticMaterial.getProperties().ensureSet(PropertyKey.INGOT, true);
    }

    /**
     * Specifies a material into which this material parts turn when heated.<br>
     * If null, material remains the same.
     */
    @Nullable
    public Material getSmeltingInto() {
        return this.smeltingInto;
    }

    /**
     * Specifies a material into which this material parts turn when heated.<br>
     * If null, material remains the same.
     */
    public void setSmeltingInto(@Nullable final Material smeltingInto) {
        this.smeltingInto = smeltingInto;
    }

    /**
     * Specifies a material into which this material parts turn when heated in arc furnace.<br>
     * If null, material remains the same.
     */
    @Nullable
    public Material getArcSmeltingInto() {
        return this.arcSmeltingInto;
    }

    /**
     * Specifies a material into which this material parts turn when heated in arc furnace.<br>
     * If null, material remains the same.
     */
    public void setArcSmeltingInto(@Nullable final Material arcSmeltingInto) {
        this.arcSmeltingInto = arcSmeltingInto;
    }

    /**
     * Specifies a Material into which this Material Macerates into.<br>
     * If null, material remains the same.
     */
    @Nullable
    public Material getMacerateInto() {
        return this.macerateInto;
    }

    /**
     * Specifies a Material into which this Material Macerates into.<br>
     * If null, material remains the same.
     */
    public void setMacerateInto(@Nullable final Material macerateInto) {
        this.macerateInto = macerateInto;
    }

    /**
     * Material which obtained when this material is polarized.<br>
     * If null, polarization recipes not generated.
     */
    @Nullable
    public Material getMagneticMaterial() {
        return this.magneticMaterial;
    }

    /**
     * Material which obtained when this material is polarized.<br>
     * If null, polarization recipes not generated.
     */
    public void setMagneticMaterial(@Nullable final Material magneticMaterial) {
        this.magneticMaterial = magneticMaterial;
    }
}
