package com.gregtechceu.gtceu.api.placeholder;

import com.gregtechceu.gtceu.api.cover.CoverBehavior;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.items.ItemStackHandler;
import org.jetbrains.annotations.Nullable;
import java.util.UUID;

public record PlaceholderContext(Level level, BlockPos pos, Direction side, @Nullable ItemStackHandler itemStackHandler, @Nullable CoverBehavior cover, @Nullable MultiLineComponent previousText, UUID uuid, int index) {
    public PlaceholderContext(Level level, BlockPos pos, Direction side, @Nullable ItemStackHandler itemStackHandler, @Nullable CoverBehavior cover, @Nullable MultiLineComponent previousText, UUID uuid) {
        this(level, pos, side, itemStackHandler, cover, previousText, uuid, 0);
    }

    /**
     * @return a clone of this object, except with this updated property (returns {@code this} if an identical value is passed).
     */
    @org.jetbrains.annotations.NotNull
    public PlaceholderContext withIndex(final int index) {
        return this.index == index ? this : new PlaceholderContext(this.level, this.pos, this.side, this.itemStackHandler, this.cover, this.previousText, this.uuid, index);
    }
}
