package com.gregtechceu.gtceu.api.placeholder;

import com.gregtechceu.gtceu.api.cover.CoverBehavior;
import com.gregtechceu.gtceu.common.machine.multiblock.electric.monitor.MonitorGroup;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.items.ItemStackHandler;
import lombok.*;
import org.jetbrains.annotations.Nullable;
import java.util.UUID;

public final class PlaceholderContext {
    private Level level;
    private BlockPos pos;
    private Direction side;
    @Nullable
    private final ItemStackHandler itemStackHandler;
    @Nullable
    private final CoverBehavior cover;
    @Nullable
    private final MonitorGroup monitorGroup;
    @Nullable
    private final MultiLineComponent previousText;
    private final UUID uuid;
    private int index;

    public PlaceholderContext(Level level, BlockPos pos, Direction side, @Nullable ItemStackHandler itemStackHandler, @Nullable CoverBehavior cover, @Nullable MonitorGroup monitorGroup, @Nullable MultiLineComponent previousText, UUID uuid) {
        this(level, pos, side, itemStackHandler, cover, monitorGroup, previousText, uuid, 0);
    }

    public PlaceholderContext(final Level level, final BlockPos pos, final Direction side, @Nullable final ItemStackHandler itemStackHandler, @Nullable final CoverBehavior cover, @Nullable final MonitorGroup monitorGroup, @Nullable final MultiLineComponent previousText, final UUID uuid, final int index) {
        this.level = level;
        this.pos = pos;
        this.side = side;
        this.itemStackHandler = itemStackHandler;
        this.cover = cover;
        this.monitorGroup = monitorGroup;
        this.previousText = previousText;
        this.uuid = uuid;
        this.index = index;
    }

    public Level level() {
        return this.level;
    }

    public BlockPos pos() {
        return this.pos;
    }

    public Direction side() {
        return this.side;
    }

    @Nullable
    public ItemStackHandler itemStackHandler() {
        return this.itemStackHandler;
    }

    @Nullable
    public CoverBehavior cover() {
        return this.cover;
    }

    @Nullable
    public MonitorGroup monitorGroup() {
        return this.monitorGroup;
    }

    @Nullable
    public MultiLineComponent previousText() {
        return this.previousText;
    }

    public UUID uuid() {
        return this.uuid;
    }

    public int index() {
        return this.index;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public PlaceholderContext level(final Level level) {
        this.level = level;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public PlaceholderContext pos(final BlockPos pos) {
        this.pos = pos;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public PlaceholderContext side(final Direction side) {
        this.side = side;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public PlaceholderContext index(final int index) {
        this.index = index;
        return this;
    }

    @org.jetbrains.annotations.NotNull
    @Override
    public String toString() {
        return "PlaceholderContext(level=" + this.level() + ", pos=" + this.pos() + ", side=" + this.side() + ", itemStackHandler=" + this.itemStackHandler() + ", cover=" + this.cover() + ", monitorGroup=" + this.monitorGroup() + ", previousText=" + this.previousText() + ", uuid=" + this.uuid() + ", index=" + this.index() + ")";
    }
}
