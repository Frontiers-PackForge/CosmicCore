package com.gregtechceu.gtceu.api.capability.recipe;

import com.gregtechceu.gtceu.GTCEu;
import brachy.modularui.drawable.UITexture;

/**
 * The capability can be input or output or both
 */
public enum IO {
    IN("import"), OUT("export"), BOTH("both"), NONE("none");
    public final String localeName;
    public final UITexture uiTexture;

    IO(String localeName) {
        this.localeName = localeName;
        this.uiTexture = UITexture.fullImage(GTCEu.id("textures/gui/icon/io_mode/" + localeName + ".png"));
    }

    public static String getTitle() {
        return "gtceu.io.title";
    }

    public String getTooltip() {
        return "gtceu.io." + localeName;
    }

    public boolean support(IO io) {
        if (io == this) return true;
        if (io == NONE) return false;
        return this == BOTH;
    }

    public UITexture getUiTexture() {
        return this.uiTexture;
    }
}
