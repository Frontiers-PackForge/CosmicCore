package com.gregtechceu.gtceu.api.capability;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.item.component.ISpoilableItem;
import com.gregtechceu.gtceu.api.machine.trait.recipe.RecipeLogic;

import net.minecraft.core.Direction;
import net.neoforged.neoforge.capabilities.BlockCapability;
import net.neoforged.neoforge.capabilities.ItemCapability;

public class GTCapability {

    public static final BlockCapability<IEnergyContainer, Direction> CAPABILITY_ENERGY_CONTAINER = BlockCapability
            .createSided(GTCEu.id("energy_container"), IEnergyContainer.class);
    public static final BlockCapability<IEnergyInfoProvider, Direction> CAPABILITY_ENERGY_INFO_PROVIDER = BlockCapability
            .createSided(GTCEu.id("energy_info_provider"), IEnergyInfoProvider.class);
    public static final BlockCapability<ICoverable, Direction> CAPABILITY_COVERABLE = BlockCapability
            .createSided(GTCEu.id("coverable"), ICoverable.class);
    public static final BlockCapability<IWorkable, Direction> CAPABILITY_WORKABLE = BlockCapability
            .createSided(GTCEu.id("workable"), IWorkable.class);
    public static final BlockCapability<IControllable, Direction> CAPABILITY_CONTROLLABLE = BlockCapability
            .createSided(GTCEu.id("controllable"), IControllable.class);
    public static final BlockCapability<RecipeLogic, Direction> CAPABILITY_RECIPE_LOGIC = BlockCapability
            .createSided(GTCEu.id("recipe_logic"), RecipeLogic.class);
    public static final ItemCapability<IElectricItem, Void> CAPABILITY_ELECTRIC_ITEM = ItemCapability
            .createVoid(GTCEu.id("electric_item"), IElectricItem.class);
    public static final BlockCapability<ILaserContainer, Direction> CAPABILITY_LASER = BlockCapability
            .createSided(GTCEu.id("laser_container"), ILaserContainer.class);
    public static final BlockCapability<IOpticalComputationProvider, Direction> CAPABILITY_COMPUTATION_PROVIDER = BlockCapability
            .createSided(GTCEu.id("computation_provider"), IOpticalComputationProvider.class);
    public static final BlockCapability<IDataAccessHatch, Direction> CAPABILITY_DATA_ACCESS = BlockCapability
            .createSided(GTCEu.id("data_access"), IDataAccessHatch.class);
    public static final BlockCapability<IHazardParticleContainer, Direction> CAPABILITY_HAZARD_CONTAINER = BlockCapability
            .createSided(GTCEu.id("hazard_particle_container"), IHazardParticleContainer.class);
    public static final BlockCapability<IMonitorComponent, Direction> CAPABILITY_MONITOR_COMPONENT = BlockCapability
            .createSided(GTCEu.id("monitor_component"), IMonitorComponent.class);
    public static final ItemCapability<ISpoilableItem, Void> CAPABILITY_SPOILABLE_ITEM = ItemCapability
            .createVoid(GTCEu.id("spoilable_item"), ISpoilableItem.class);
}
