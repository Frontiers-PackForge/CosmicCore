package com.gregtechceu.gtceu.api.recipe;

import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.Unmodifiable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public class ConsumedInputsData {
    public static final Codec<ConsumedInputsData> CODEC = RecordCodecBuilder.create(instance -> instance.group(RecipeCapability.INGREDIENT_CODEC.optionalFieldOf("consumedInputs", new HashMap<>()).xmap((map -> (Map<RecipeCapability<?>, List<?>>) new HashMap(map)), Function.identity()).forGetter(ConsumedInputsData::getConsumedInputs)).apply(instance, ConsumedInputsData::new));
    /**
     * Populated after the inputs are already consumed, but the recipe didn't start yet.
     * For use in {@link GTRecipe#outputModifier}
     */
    private Map<RecipeCapability<?>, List<?>> consumedInputs;

    public ConsumedInputsData() {
        this(new HashMap<>());
    }

    public ConsumedInputsData copy() {
        HashMap<RecipeCapability<?>, List<?>> copied = new HashMap<>();
        for (Map.Entry<RecipeCapability<?>, List<?>> entry : consumedInputs.entrySet()) {
            copied.put(entry.getKey(), new ArrayList<>(entry.getValue().stream().map(entry.getKey()::copyContent).toList()));
        }
        return new ConsumedInputsData(copied);
    }

    public void clear() {
        consumedInputs.clear();
    }

    public <T> void addConsumedInput(RecipeCapability<T> recipeCapability, T t) {
        // noinspection unchecked why can't I just add whatever I want to a List<?>
        ((List<T>) consumedInputs.computeIfAbsent(recipeCapability, cap -> new ArrayList<>())).add(t);
    }

    @Unmodifiable
    public <T> List<T> getConsumedInputs(RecipeCapability<T> recipeCapability) {
        // noinspection unchecked
        return (List<T>) consumedInputs.getOrDefault(recipeCapability, List.of());
    }

    /**
     * Creates a new {@code ConsumedInputsData} instance.
     *
     * @param consumedInputs Populated after the inputs are already consumed, but the recipe didn't start yet.
     * For use in {@link GTRecipe#outputModifier}
     */
    public ConsumedInputsData(final Map<RecipeCapability<?>, List<?>> consumedInputs) {
        this.consumedInputs = consumedInputs;
    }

    /**
     * Populated after the inputs are already consumed, but the recipe didn't start yet.
     * For use in {@link GTRecipe#outputModifier}
     */
    private Map<RecipeCapability<?>, List<?>> getConsumedInputs() {
        return this.consumedInputs;
    }
}
