package com.gregtechceu.gtceu.api.recipe.gui;

import com.gregtechceu.gtceu.api.mui.SteamTextureSet;
import brachy.modularui.drawable.UITexture;
import brachy.modularui.drawable.progress.ProgressDrawable;
import org.jetbrains.annotations.Nullable;

public class ProgressBarTextureSet extends SteamTextureSet {
    private final int progressSize;
    private final ProgressDrawable.Direction fillDirection;

    public ProgressBarTextureSet(int progressSize, ProgressDrawable.Direction fillDirection, UITexture main, @Nullable UITexture bronze, @Nullable UITexture steel) {
        super(main, bronze, steel);
        this.progressSize = progressSize;
        this.fillDirection = fillDirection;
    }

    public ProgressBarTextureSet(UITexture main, UITexture bronze, UITexture steel) {
        this(20, ProgressDrawable.Direction.RIGHT, main, bronze, steel);
    }

    public ProgressBarTextureSet(UITexture main) {
        this(20, ProgressDrawable.Direction.RIGHT, main);
    }

    public ProgressBarTextureSet(int progressSize, ProgressDrawable.Direction fillDirection, UITexture main) {
        this(progressSize, fillDirection, main, null, null);
    }

    public int progressSize() {
        return this.progressSize;
    }

    public ProgressDrawable.Direction fillDirection() {
        return this.fillDirection;
    }
}
