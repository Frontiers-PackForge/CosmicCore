package com.gregtechceu.gtceu.api.recipe;

import com.gregtechceu.gtceu.api.machine.trait.recipe.RecipeLogic;
import com.gregtechceu.gtceu.api.recipe.condition.RecipeConditionType;
import com.gregtechceu.gtceu.api.recipe.gui.RecipeUIModifier;
import com.gregtechceu.gtceu.api.registry.GTRegistries;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.RegistryOps;
import brachy.modularui.api.drawable.Text;
import com.google.gson.JsonObject;
import com.mojang.datafixers.Products;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.NotNull;
import java.util.function.Function;

public abstract class RecipeCondition<T extends RecipeCondition<T>> {
    public static final Codec<RecipeCondition<?>> CODEC = GTRegistries.RECIPE_CONDITIONS.byNameCodec().dispatch(RecipeCondition::getType, RecipeConditionType::getCodec);

    // spotless:off
    public static <RC extends RecipeCondition<RC>> Products.P1<RecordCodecBuilder.Mu<RC>, Boolean> isReverse(RecordCodecBuilder.Instance<RC> instance) {
        return instance.group(Codec.BOOL.optionalFieldOf("reverse", false).forGetter(val -> val.isReverse));
    }

    // spotless:on
    public static <RC extends RecipeCondition<RC>> MapCodec<RC> simpleCodec(Function<Boolean, RC> function) {
        return RecordCodecBuilder.mapCodec(instance -> isReverse(instance).apply(instance, function));
    }

    protected boolean isReverse;

    public RecipeCondition() {
        this(false);
    }

    public RecipeCondition(boolean isReverse) {
        this.isReverse = isReverse;
    }

    public abstract RecipeConditionType<T> getType();

    public boolean isOr() {
        return false;
    }

    public abstract Component getTooltips();

    public RecipeUIModifier modifyUI() {
        return RecipeUIModifier.textLine(Text.of(getTooltips()));
    }

    public boolean check(@NotNull GTRecipe recipe, @NotNull RecipeLogic recipeLogic) {
        boolean test = testCondition(recipe, recipeLogic);
        return test != isReverse;
    }

    protected abstract boolean testCondition(@NotNull GTRecipe recipe, @NotNull RecipeLogic recipeLogic);

    public abstract T createTemplate();

    @NotNull
    public final JsonObject serialize() {
        var ops = RegistryOps.create(JsonOps.INSTANCE, GTRegistries.builtinRegistry());
        return CODEC.encodeStart(ops, this).getOrThrow().getAsJsonObject();
    }

    public static RecipeCondition<?> deserialize(@NotNull JsonObject config) {
        var ops = RegistryOps.create(JsonOps.INSTANCE, GTRegistries.builtinRegistry());
        return CODEC.decode(ops, config).getOrThrow().getFirst();
    }

    public final void toNetwork(RegistryFriendlyByteBuf buf) {
        var ops = RegistryOps.create(NbtOps.INSTANCE, buf.registryAccess());
        buf.writeWithCodec(ops, CODEC, this);
    }

    public static RecipeCondition<?> fromNetwork(RegistryFriendlyByteBuf buf) {
        var ops = RegistryOps.create(NbtOps.INSTANCE, buf.registryAccess());
        return buf.readWithCodec(ops, CODEC, NbtAccounter.create(FriendlyByteBuf.DEFAULT_NBT_QUOTA));
    }

    public boolean isReverse() {
        return this.isReverse;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public RecipeCondition<T> setReverse(final boolean isReverse) {
        this.isReverse = isReverse;
        return this;
    }
}
