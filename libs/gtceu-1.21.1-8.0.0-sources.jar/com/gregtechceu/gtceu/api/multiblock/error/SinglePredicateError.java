package com.gregtechceu.gtceu.api.multiblock.error;

import com.gregtechceu.gtceu.api.multiblock.predicates.SettingsHolder;
import com.gregtechceu.gtceu.api.multiblock.util.BlockInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.util.StringRepresentable;
import brachy.modularui.api.drawable.Text;
import brachy.modularui.drawable.ItemDrawable;
import brachy.modularui.widget.ParentWidget;
import brachy.modularui.widgets.menu.ContextMenuButton;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;

public class SinglePredicateError extends PatternError {
    // spotless:off
    public static final MapCodec<SinglePredicateError> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(ErrorType.CODEC.fieldOf("error_type").forGetter(e -> e.type), Codec.INT.fieldOf("actual_count").forGetter(e -> e.actualCount), Codec.INT.fieldOf("pred_min_count").forGetter(e -> e.predMinCount), Codec.INT.fieldOf("pred_max_count").forGetter(e -> e.predMaxCount), Codec.INT.fieldOf("pred_min_layer_count").forGetter(e -> e.predMinLayerCount), Codec.INT.fieldOf("pred_max_layer_count").forGetter(e -> e.predMaxLayerCount), Codec.STRING.fieldOf("name").forGetter(e -> e.debugName), BlockInfo.CODEC.listOf().fieldOf("candidates").forGetter(e -> e.candidates)).apply(instance, SinglePredicateError::new));
    //spotless:on
    public final ErrorType type;
    public final int actualCount;
    // Fields from BasePredicate that we need
    public final List<BlockInfo> candidates;
    public final int predMinCount;
    public final int predMaxCount;
    public final int predMinLayerCount;
    public final int predMaxLayerCount;
    public final String debugName;

    public SinglePredicateError(SettingsHolder<?> holder, List<BlockInfo> candidates, ErrorType type, int actualCount) {
        this(type, actualCount, holder.getMinCount(), holder.getMaxCount(), holder.getMinSliceCount(), holder.getMaxSliceCount(), holder.toString(), candidates);
    }

    public SinglePredicateError(ErrorType type, int actualCount, int minCount, int maxCount, int minLayerCount, int maxLayerCount, String name, List<BlockInfo> candidates) {
        this.type = type;
        this.actualCount = actualCount;
        this.candidates = candidates;
        this.predMinCount = minCount;
        this.predMaxCount = maxCount;
        this.predMinLayerCount = minLayerCount;
        this.predMaxLayerCount = maxLayerCount;
        this.debugName = name;
    }

    @Override
    public PatternErrorUI getPatternErrorUIModifier() {
        return parent -> {
            parent.child(Text.of(Component.translatable(debugName)).asWidget());
            this.type.appendComponent(parent, this);
            parent.child(new ContextMenuButton<>("predicate").menuList(l -> l.maxSize(40).children(candidates, candidate -> {
                return new ItemDrawable(candidate.getItemStackForm()).asWidget().tooltip(r -> r.add(candidate.getItemStackForm().getHoverName()));
            })));
        };
    }

    public static SinglePredicateError maxCount(SettingsHolder<?> failingPredicate, List<BlockInfo> candidates, int actualCount) {
        return new SinglePredicateError(failingPredicate, candidates, ErrorType.MAX_COUNT, actualCount);
    }

    public static SinglePredicateError minCount(SettingsHolder<?> failingPredicate, List<BlockInfo> candidates, int actualCount) {
        return new SinglePredicateError(failingPredicate, candidates, ErrorType.MIN_COUNT, actualCount);
    }

    public static SinglePredicateError maxLayerCount(SettingsHolder<?> failingPredicate, List<BlockInfo> candidates, int actualCount) {
        return new SinglePredicateError(failingPredicate, candidates, ErrorType.MAX_LAYER_COUNT, actualCount);
    }

    public static SinglePredicateError minLayerCount(SettingsHolder<?> failingPredicate, List<BlockInfo> candidates, int actualCount) {
        return new SinglePredicateError(failingPredicate, candidates, ErrorType.MIN_LAYER_COUNT, actualCount);
    }


    public enum ErrorType implements StringRepresentable {
        MAX_COUNT("max_count"), MIN_COUNT("min_count"), MAX_LAYER_COUNT("max_layer_count"), MIN_LAYER_COUNT("min_layer_count");
        final String name;

        ErrorType(String name) {
            this.name = name;
        }

        public static final Codec<ErrorType> CODEC = StringRepresentable.fromEnum(ErrorType::values);

        @Override
        public String getSerializedName() {
            return getName();
        }

        private void appendComponent(ParentWidget<?> parent, SinglePredicateError error) {
            parent.child(Text.of(getComponent(error)).asWidget());
        }

        private Component getComponent(SinglePredicateError error) {
            return switch (this) {
                case MAX_COUNT -> Component.translatable("gtceu.multiblock.pattern.error.limited.max_count", error.predMaxCount, error.actualCount);
                case MIN_COUNT -> Component.translatable("gtceu.multiblock.pattern.error.limited.min_count", error.predMinCount, error.actualCount);
                case MAX_LAYER_COUNT -> Component.translatable("gtceu.multiblock.pattern.error.limited.max_layer_count", error.predMaxLayerCount, error.actualCount);
                case MIN_LAYER_COUNT -> Component.translatable("gtceu.multiblock.pattern.error.limited.min_layer_count", error.predMinLayerCount, error.actualCount);
            };
        }

        public String getName() {
            return this.name;
        }
    }

    @Override
    public PatternErrorType type() {
        return GTPatternErrors.SINGLE_PREDICATE_ERROR.value();
    }
}
