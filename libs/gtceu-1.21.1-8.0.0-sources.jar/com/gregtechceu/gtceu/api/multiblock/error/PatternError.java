package com.gregtechceu.gtceu.api.multiblock.error;

import com.gregtechceu.gtceu.api.registry.GTRegistries;
import net.minecraft.core.BlockPos;
import com.mojang.serialization.Codec;

public abstract class PatternError {
    public static final Codec<PatternError> CODEC = GTRegistries.PATTERN_ERROR_TYPES.byNameCodec().dispatch(PatternError::type, PatternErrorType::codec);
    protected BlockPos pos;

    public PatternError(BlockPos pos) {
        this.pos = pos;
    }

    protected PatternError() {
        this.pos = BlockPos.ZERO;
    }

    public abstract PatternErrorType type();

    public abstract PatternErrorUI getPatternErrorUIModifier();

    public BlockPos getPos() {
        return this.pos;
    }
}
