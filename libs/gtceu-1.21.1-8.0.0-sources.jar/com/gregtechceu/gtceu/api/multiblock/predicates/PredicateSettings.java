package com.gregtechceu.gtceu.api.multiblock.predicates;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

public record PredicateSettings(int priority, int minCount, int maxCount, int minSliceCount, int maxSliceCount, int previewCount, boolean disableRenderFormed) {
    // spotless:off
    public static final Codec<PredicateSettings> CODEC = RecordCodecBuilder.create(instance -> instance.group(Codec.INT.fieldOf("priority").forGetter(PredicateSettings::priority), Codec.INT.fieldOf("min_count").forGetter(PredicateSettings::minCount), Codec.INT.fieldOf("max_count").forGetter(PredicateSettings::maxCount), Codec.INT.fieldOf("min_layer_count").forGetter(PredicateSettings::minSliceCount), Codec.INT.fieldOf("max_layer_count").forGetter(PredicateSettings::maxSliceCount), Codec.INT.fieldOf("preview_count").forGetter(PredicateSettings::previewCount), Codec.BOOL.fieldOf("disable_render_formed").forGetter(PredicateSettings::disableRenderFormed)).apply(instance, PredicateSettings::new));
    // spotless:on
    public static final int MAX_PRIORITY = Integer.MAX_VALUE;
    public static final int MIN_PRIORITY = Integer.MIN_VALUE;

    // helper for xor
    public boolean isNoneValid() {
        return minCount <= 0 && minSliceCount <= 0;
    }

    public PredicateSettings copy() {
        return new PredicateSettings(this.priority, this.minCount, this.maxCount, this.minSliceCount, this.maxSliceCount, this.previewCount, this.disableRenderFormed);
    }

    public static PredicateSettings create() {
        return new PredicateSettings(0, -1, -1, -1, -1, -1, false);
    }

    /**
     * @return a clone of this object, except with this updated property (returns {@code this} if an identical value is passed).
     */
    @org.jetbrains.annotations.NotNull
    public PredicateSettings withPriority(final int priority) {
        return this.priority == priority ? this : new PredicateSettings(priority, this.minCount, this.maxCount, this.minSliceCount, this.maxSliceCount, this.previewCount, this.disableRenderFormed);
    }

    /**
     * @return a clone of this object, except with this updated property (returns {@code this} if an identical value is passed).
     */
    @org.jetbrains.annotations.NotNull
    public PredicateSettings withMinCount(final int minCount) {
        return this.minCount == minCount ? this : new PredicateSettings(this.priority, minCount, this.maxCount, this.minSliceCount, this.maxSliceCount, this.previewCount, this.disableRenderFormed);
    }

    /**
     * @return a clone of this object, except with this updated property (returns {@code this} if an identical value is passed).
     */
    @org.jetbrains.annotations.NotNull
    public PredicateSettings withMaxCount(final int maxCount) {
        return this.maxCount == maxCount ? this : new PredicateSettings(this.priority, this.minCount, maxCount, this.minSliceCount, this.maxSliceCount, this.previewCount, this.disableRenderFormed);
    }

    /**
     * @return a clone of this object, except with this updated property (returns {@code this} if an identical value is passed).
     */
    @org.jetbrains.annotations.NotNull
    public PredicateSettings withMinSliceCount(final int minSliceCount) {
        return this.minSliceCount == minSliceCount ? this : new PredicateSettings(this.priority, this.minCount, this.maxCount, minSliceCount, this.maxSliceCount, this.previewCount, this.disableRenderFormed);
    }

    /**
     * @return a clone of this object, except with this updated property (returns {@code this} if an identical value is passed).
     */
    @org.jetbrains.annotations.NotNull
    public PredicateSettings withMaxSliceCount(final int maxSliceCount) {
        return this.maxSliceCount == maxSliceCount ? this : new PredicateSettings(this.priority, this.minCount, this.maxCount, this.minSliceCount, maxSliceCount, this.previewCount, this.disableRenderFormed);
    }

    /**
     * @return a clone of this object, except with this updated property (returns {@code this} if an identical value is passed).
     */
    @org.jetbrains.annotations.NotNull
    public PredicateSettings withPreviewCount(final int previewCount) {
        return this.previewCount == previewCount ? this : new PredicateSettings(this.priority, this.minCount, this.maxCount, this.minSliceCount, this.maxSliceCount, previewCount, this.disableRenderFormed);
    }

    /**
     * @return a clone of this object, except with this updated property (returns {@code this} if an identical value is passed).
     */
    @org.jetbrains.annotations.NotNull
    public PredicateSettings withDisableRenderFormed(final boolean disableRenderFormed) {
        return this.disableRenderFormed == disableRenderFormed ? this : new PredicateSettings(this.priority, this.minCount, this.maxCount, this.minSliceCount, this.maxSliceCount, this.previewCount, disableRenderFormed);
    }
}
