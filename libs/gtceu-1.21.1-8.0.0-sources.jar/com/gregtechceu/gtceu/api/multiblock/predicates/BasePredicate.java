package com.gregtechceu.gtceu.api.multiblock.predicates;

import com.gregtechceu.gtceu.api.multiblock.MultiPredicate;
import com.gregtechceu.gtceu.api.multiblock.PredicateContext;
import com.gregtechceu.gtceu.api.multiblock.error.SinglePredicateError;
import com.gregtechceu.gtceu.api.multiblock.util.BlockInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import java.util.*;

public abstract class BasePredicate implements Comparable<BasePredicate> {
    public static final BasePredicate AIR = new PredicateBuilder("Air").predicate(ctx -> ctx.state().isAir()).build();
    public static final BasePredicate ANY = new PredicateBuilder("Any").predicate(ctx -> true).build();
    private final java.util.concurrent.atomic.AtomicReference<Object> candidates = new java.util.concurrent.atomic.AtomicReference<Object>();
    protected int priority = 0;
    protected int minCount = -1;
    protected int maxCount = -1;
    protected int minSliceCount = -1;
    protected int maxSliceCount = -1;
    protected int previewCount = -1;
    protected boolean disableRenderFormed = false;
    @Nullable
    private String nbtParser; // unsure what this does
    @Nullable
    private MultiPredicate parent;
    private final List<Component> additionalTooltips = new ArrayList<>();

    public MultiPredicate getParent() {
        return Objects.requireNonNull(this.parent);
    }

    /// the main testing method
    public abstract boolean test(PredicateContext ctx);

    public abstract void onError(PredicateContext ctx);

    public abstract BasePredicate copy();

    protected void copyTo(BasePredicate other) {
        other.priority = this.priority;
        other.minCount = this.minCount;
        other.maxCount = this.maxCount;
        other.minSliceCount = this.minSliceCount;
        other.maxSliceCount = this.maxSliceCount;
        other.previewCount = this.previewCount;
        other.disableRenderFormed = this.disableRenderFormed;
        other.nbtParser = this.nbtParser;
        other.additionalTooltips.addAll(this.additionalTooltips);
    }

    public void addTooltips(Component tooltip) {
        this.additionalTooltips.add(tooltip);
    }

    /// delegates to {@link MultiPredicate#testMaxCount(BasePredicate, PredicateContext)},
    /// with this predicate as the passing predicate
    public boolean checkMaxCount(PredicateContext context) {
        return getParent().testMaxCount(this, context);
    }

    /// test against global max count
    public boolean testGlobalMax(PredicateContext ctx) {
        int count = ctx.incrementGlobalCount(this);
        if (testGlobalMax(count)) return true;
        ctx.appendError(SinglePredicateError.maxCount(this, count));
        return false;
    }

    /// test against slice max count
    public boolean testSliceMax(PredicateContext ctx) {
        if (!ctx.isCheckLayer()) return true;
        int count = ctx.incrementSliceCount(this);
        if (testSliceMax(count)) return true;
        ctx.appendError(SinglePredicateError.maxLayerCount(this, count));
        return false;
    }

    /// test against global min count
    public boolean testGlobalMin(PredicateContext ctx) {
        if (getMinCount() == -1) return true;
        int count = ctx.getGlobalCount(this);
        if (testGlobalMin(count)) return true;
        ctx.appendError(SinglePredicateError.minCount(this, count));
        return false;
    }

    /// test against slice min count
    public boolean testSliceMin(PredicateContext ctx) {
        if (!ctx.isCheckLayer()) return true;
        int count = ctx.getSliceCount(this);
        if (testSliceMin(count)) return true;
        ctx.appendError(SinglePredicateError.minLayerCount(this, count));
        return false;
    }

    /// simple test against global min count
    public boolean testGlobalMin(int count) {
        return minCount == -1 || count >= minCount;
    }

    /// simple test against slice min count
    public boolean testSliceMin(int count) {
        return minSliceCount == -1 || count >= minSliceCount;
    }

    /// simple test against global max count
    public boolean testGlobalMax(int count) {
        return maxCount == -1 || count <= maxCount;
    }

    /// simple test against slice max count
    public boolean testSliceMax(int count) {
        return maxSliceCount == -1 || count <= maxSliceCount;
    }

    /// computes the candidates for this predicate
    public abstract List<BlockInfo> computeCandidates();

    public List<ItemStack> getCandidateStacks() {
        return getCandidates().stream().filter(BlockInfo::nonAir).map(BlockInfo::getItemStackForm).toList();
    }

    public Optional<BlockInfo> getFirstCandidate() {
        return Optional.of(getCandidates()).filter(c -> !c.isEmpty()).map(c -> c.get(0));
    }

    /// the type of this predicate
    public abstract String getTypeName();

    /// the contents of this predicate
    protected void appendContents(StringBuilder builder) {
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder(getTypeName());
        builder.append('{');
        appendContents(builder);
        builder.append('}');
        return builder.toString();
    }

    @Override
    public int compareTo(BasePredicate o) {
        return Integer.compare(this.priority, o.priority);
    }

    public List<BlockInfo> getCandidates() {
        Object $value = this.candidates.get();
        if ($value == null) {
            synchronized (this.candidates) {
                $value = this.candidates.get();
                if ($value == null) {
                    final List<BlockInfo> actualValue = computeCandidates();
                    $value = actualValue == null ? this.candidates : actualValue;
                    this.candidates.set($value);
                }
            }
        }
        return (List<BlockInfo>) ($value == this.candidates ? null : $value);
    }

    public int getPriority() {
        return this.priority;
    }

    public void setPriority(final int priority) {
        this.priority = priority;
    }

    public int getMinCount() {
        return this.minCount;
    }

    public void setMinCount(final int minCount) {
        this.minCount = minCount;
    }

    public int getMaxCount() {
        return this.maxCount;
    }

    public void setMaxCount(final int maxCount) {
        this.maxCount = maxCount;
    }

    public int getMinSliceCount() {
        return this.minSliceCount;
    }

    public void setMinSliceCount(final int minSliceCount) {
        this.minSliceCount = minSliceCount;
    }

    public int getMaxSliceCount() {
        return this.maxSliceCount;
    }

    public void setMaxSliceCount(final int maxSliceCount) {
        this.maxSliceCount = maxSliceCount;
    }

    public int getPreviewCount() {
        return this.previewCount;
    }

    public void setPreviewCount(final int previewCount) {
        this.previewCount = previewCount;
    }

    public boolean isDisableRenderFormed() {
        return this.disableRenderFormed;
    }

    public void setDisableRenderFormed(final boolean disableRenderFormed) {
        this.disableRenderFormed = disableRenderFormed;
    }

    @Nullable
    public String getNbtParser() {
        return this.nbtParser;
    }

    public void setNbtParser(@Nullable final String nbtParser) {
        this.nbtParser = nbtParser;
    }

    public void setParent(@Nullable final MultiPredicate parent) {
        this.parent = parent;
    }

    public List<Component> getAdditionalTooltips() {
        return this.additionalTooltips;
    }
}
