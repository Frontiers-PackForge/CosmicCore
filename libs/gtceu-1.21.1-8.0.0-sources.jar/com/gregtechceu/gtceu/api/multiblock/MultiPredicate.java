package com.gregtechceu.gtceu.api.multiblock;

import com.gregtechceu.gtceu.api.multiblock.error.PatternStringError;
import com.gregtechceu.gtceu.api.multiblock.predicates.BasePredicate;
import com.gregtechceu.gtceu.api.multiblock.util.BlockInfo;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.CheckReturnValue;
import org.jetbrains.annotations.Nullable;
import java.util.*;
import java.util.function.Consumer;

public abstract class MultiPredicate {
    private static final MultiPredicate EMPTY = of(Logic.OR, List.of());
    public static final MultiPredicate AIR = of(BasePredicate.AIR);
    public static final MultiPredicate ANY = of(BasePredicate.ANY);
    private final List<BasePredicate> predicates;
    private final List<MultiPredicate> children;
    private final boolean hasAir;
    private final Logic type;
    private boolean controller;
    @Nullable
    private MultiPredicate parent;

    public static MultiPredicate of(BasePredicate predicate) {
        return Logic.OR.makePredicate(predicate, predicate == BasePredicate.AIR);
    }

    /// @param predicates list must be modifiable
    private static MultiPredicate of(Logic type, List<BasePredicate> predicates) {
        return type.makePredicate(List.of(), predicates, predicates.stream().anyMatch(p -> p == BasePredicate.AIR));
    }

    /// @param children list of multi predicate children
    /// @param predicates list of testable predicates, should be sorted already
    protected MultiPredicate(Logic type, List<MultiPredicate> children, List<BasePredicate> predicates, boolean hasAir) {
        predicates.forEach(p -> p.setParent(this));
        children.forEach(mp -> mp.setParent(this));
        this.predicates = Collections.unmodifiableList(predicates);
        this.children = Collections.unmodifiableList(children);
        this.type = type;
        this.hasAir = hasAir;
    }

    /// @return innermost base predicate that passes state check at given pos
    @Nullable
    public BasePredicate getPredicateAtPos(PredicateContext context) {
        context.setStage(PredicateContext.PredicateStage.INTERNAL);
        for (BasePredicate predicate : predicates()) {
            if (predicate.test(context)) {
                return predicate;
            }
        }
        for (MultiPredicate predicates : children()) {
            BasePredicate p = predicates.getPredicateAtPos(context);
            if (p != null) return p;
        }
        if (isRoot()) {
            onError(context);
        }
        return null;
    }

    /// called when all predicates failed
    protected void onError(PredicateContext ctx) {
        this.forEach(p -> p.onError(ctx));
        this.forEachChild(mp -> mp.onError(ctx));
    }

    /// Called after all blocks are iterated <br/>
    /// Usually used for testing the global min of predicates
    public final boolean postGlobalTest(PredicateContext ctx) {
        ctx.setStage(PredicateContext.PredicateStage.GLOBAL_MIN);
        if (testGlobalMin(ctx)) return true;
        for (Component content : getDescriptiveContents()) {
            ctx.appendError(PatternStringError.component(content));
        }
        return false;
    }

    protected abstract boolean testGlobalMin(PredicateContext ctx);

    /// Called after iterating all blocks in a given slice <br/>
    /// Usually used for testing the slice min of predicates
    public final boolean postSliceTest(PredicateContext ctx) {
        ctx.setStage(PredicateContext.PredicateStage.SLICE_MIN);
        if (testSliceMin(ctx)) return true;
        for (Component content : getDescriptiveContents()) {
            ctx.appendError(PatternStringError.component(content));
        }
        return false;
    }

    protected abstract boolean testSliceMin(PredicateContext ctx);

    /// test against global/slice max counts
    public boolean testMaxCount(BasePredicate passedPredicate, PredicateContext context) {
        context.setStage(PredicateContext.PredicateStage.GLOBAL_MAX);
        if (!passedPredicate.testGlobalMax(context)) return false;
        context.setStage(PredicateContext.PredicateStage.SLICE_MAX);
        return passedPredicate.testSliceMax(context);
    }

    public List<List<BlockInfo>> getCandidates() {
        List<List<BlockInfo>> result = new ArrayList<>();
        for (BasePredicate predicate : predicates()) {
            result.add(predicate.getCandidates());
        }
        for (MultiPredicate child : children()) {
            result.addAll(child.getCandidates());
        }
        return Collections.unmodifiableList(result);
    }

    public void resetLogic() {
        this.children.forEach(MultiPredicate::resetLogic);
    }

    public boolean isOr() {
        return this.getType() == Logic.OR;
    }

    public boolean isAnd() {
        return this.getType() == Logic.AND;
    }

    public boolean isXor() {
        return this.getType() == Logic.XOR;
    }

    private boolean isType(Logic type) {
        return this.type == type;
    }

    @ApiStatus.Internal
    public boolean isEmpty() {
        return this == EMPTY;
    }

    public boolean isAny() {
        return this == ANY;
    }

    public boolean isAir() {
        return this == AIR;
    }

    public boolean hasAir() {
        return this.hasAir;
    }

    @CheckReturnValue
    private MultiPredicate mutatedCopy(Consumer<BasePredicate> mutation) {
        List<BasePredicate> copiedPredicates = new ArrayList<>(this.predicates.size());
        for (BasePredicate predicate : this.predicates) {
            BasePredicate copy = predicate.copy();
            mutation.accept(copy);
            copiedPredicates.add(copy);
        }
        List<MultiPredicate> copiedChildren = new ArrayList<>(this.children.size());
        for (MultiPredicate child : this.children) {
            copiedChildren.add(child.mutatedCopy(mutation));
        }
        MultiPredicate copy = this.type.makePredicate(copiedChildren, copiedPredicates, this.hasAir);
        copy.setController(this.controller);
        return copy;
    }

    @CheckReturnValue
    public MultiPredicate addTooltips(Component tooltip) {
        return mutatedCopy(p -> p.addTooltips(tooltip));
    }

    @CheckReturnValue
    public MultiPredicate setPriority(int priority) {
        return mutatedCopy(p -> p.setPriority(priority));
    }

    @CheckReturnValue
    public MultiPredicate setMinGlobalLimited(int min) {
        return this.setMinCount(min);
    }

    @CheckReturnValue
    public MultiPredicate setMinGlobalLimited(int min, int previewCount) {
        return this.setMinCount(min).setPreviewCount(previewCount);
    }

    @CheckReturnValue
    public MultiPredicate setMinCount(int min) {
        return mutatedCopy(p -> p.setMinCount(min));
    }

    @CheckReturnValue
    public MultiPredicate setMaxGlobalLimited(int max) {
        return this.setMaxCount(max);
    }

    @CheckReturnValue
    public MultiPredicate setMaxGlobalLimited(int max, int previewCount) {
        return this.setMaxCount(max).setPreviewCount(previewCount);
    }

    @CheckReturnValue
    public MultiPredicate setMaxCount(int max) {
        return mutatedCopy(p -> p.setMaxCount(max));
    }

    @CheckReturnValue
    public MultiPredicate setGlobalMinMax(int min, int max) {
        return this.setMinCount(min).setMaxCount(max);
    }

    @CheckReturnValue
    public MultiPredicate setMinLayerLimited(int min) {
        return this.setMinSliceCount(min);
    }

    @CheckReturnValue
    public MultiPredicate setMinLayerLimited(int min, int previewCount) {
        return this.setMinSliceCount(min).setPreviewCount(previewCount);
    }

    @CheckReturnValue
    public MultiPredicate setMinSliceCount(int min) {
        return mutatedCopy(p -> p.setMinSliceCount(min));
    }

    @CheckReturnValue
    public MultiPredicate setMaxLayerLimited(int max) {
        return this.setMaxSliceCount(max);
    }

    @CheckReturnValue
    public MultiPredicate setMaxLayerLimited(int max, int previewCount) {
        return this.setMaxSliceCount(max).setPreviewCount(previewCount);
    }

    @CheckReturnValue
    public MultiPredicate setMaxSliceCount(int max) {
        return mutatedCopy(p -> p.setMaxSliceCount(max));
    }

    @CheckReturnValue
    public MultiPredicate setPreviewCount(int previewCount) {
        return mutatedCopy(p -> p.setPreviewCount(previewCount));
    }

    @CheckReturnValue
    public MultiPredicate setLayerMinMax(int min, int max) {
        return this.setMinSliceCount(min).setMaxSliceCount(max);
    }

    /**
     * Sets the Minimum and Maximum limit to the passed value
     *
     * @param limit The Maximum and Minimum limit
     */
    @CheckReturnValue
    public MultiPredicate setExactLimit(int limit) {
        return this.setGlobalMinMax(limit, limit);
    }

    @CheckReturnValue
    public MultiPredicate disabledRenderFormed() {
        return setDisableRenderFormed(true);
    }

    @CheckReturnValue
    public MultiPredicate setDisableRenderFormed(boolean disable) {
        return mutatedCopy(p -> p.setDisableRenderFormed(disable));
    }

    /// @return a new multi predicate where any predicate may pass or be present in the multiblock
    public MultiPredicate or(@Nullable MultiPredicate other) {
        return combine(this, Logic.OR, other);
    }

    /// @return a new multi predicate where every predicate must pass or be present in the multiblock
    public MultiPredicate and(@Nullable MultiPredicate other) {
        return combine(this, Logic.AND, other);
    }

    /// @return a new multi predicate with every predicate exclusively <br/>
    /// OR-ed (only one predicate may be present in the multi)
    public MultiPredicate xor(@Nullable MultiPredicate other) {
        return combine(this, Logic.XOR, other);
    }

    /// @return a new multi predicate where any predicate may pass or be present in the multiblock
    public static MultiPredicate or(List<BasePredicate> predicates) {
        return of(Logic.OR, predicates);
    }

    /// @return a new multi predicate where every predicate must pass or be present in the multiblock
    public static MultiPredicate and(List<BasePredicate> predicates) {
        return of(Logic.AND, predicates);
    }

    /// @return a new multi predicate with every predicate exclusively <br/>
    /// OR-ed (only one predicate may be present in the multi)
    public static MultiPredicate xor(List<BasePredicate> predicates) {
        return of(Logic.XOR, predicates);
    }

    /// @return {@code true} if this multi predicate has only one predicate and has no children
    public boolean isSingle() {
        return predicates.size() == 1 && isLeaf();
    }

    /// @return {@code true} if this multi predicate has no parent
    public boolean isRoot() {
        return getParent() == null;
    }

    /// @return {@code true} if this multi predicate has children and is not a root predicate
    public boolean isBranch() {
        return !isLeaf() && !isRoot();
    }

    /// @return {@code true} if this multi predicate has no children multi predicates
    public boolean isLeaf() {
        return this.children.isEmpty();
    }

    public List<Component> getDescriptiveContents() {
        List<Component> list = new ArrayList<>();
        Component logicLine = switch (this.type) {
            case OR -> Component.literal("any of:");
            case AND -> Component.literal("all of:");
            case XOR -> Component.literal("one of:");
        };
        list.add(logicLine);
        for (BasePredicate predicate : this.predicates) {
            // todo prettier string?
            list.add(Component.literal(predicate.toString()));
        }
        for (MultiPredicate child : children()) {
            list.addAll(child.getDescriptiveContents());
        }
        return list;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("MultiPredicate");
        builder.append('[');
        if (isController()) builder.append("Controller=true, ");
        switch (this.type) {
            case OR -> builder.append("Logic=OR");
            case AND -> builder.append("Logic=AND");
            case XOR -> builder.append("Logic=XOR");
        }
        builder.append(']');
        builder.append('{');
        StringJoiner joiner = new StringJoiner(", ");
        this.forEach(p -> joiner.add(p.toString()));
        builder.append(joiner);
        builder.append('}');
        return builder.toString();
    }

    protected void forEach(Consumer<BasePredicate> action) {
        this.predicates.forEach(action);
    }

    public List<BasePredicate> predicates() {
        return this.predicates;
    }

    public void forEachChild(Consumer<MultiPredicate> action) {
        this.children.forEach(action);
    }

    public List<MultiPredicate> children() {
        return this.children;
    }

    /// @return a flattened list of all base predicates
    public List<BasePredicate> expand() {
        if (isLeaf()) return this.predicates;
        List<BasePredicate> expanded = new ArrayList<>(this.predicates);
        forEachChild(mp -> expanded.addAll(mp.expand()));
        return expanded;
    }

    public static MultiPredicate empty() {
        return EMPTY;
    }

    /// @param a left operand
    /// @param type logic of the new predicate
    /// @param b right operand, may be null
    /// @return If {@code b == null}, returns {@code a}. <br />
    /// If {@code a == EMPTY}, returns {@code b}. <br />
    /// Otherwise, returns a new MultiPredicate that combines {@code a} and {@code b}
    private static MultiPredicate combine(MultiPredicate a, Logic type, @Nullable MultiPredicate b) {
        if (b == null || b.isEmpty()) return a; // no op
        if (a.isEmpty()) return b;
        List<BasePredicate> predicates = new ArrayList<>();
        List<MultiPredicate> children = new ArrayList<>();
        appendPredicates(type, a, predicates, children);
        appendPredicates(type, b, predicates, children);
        predicates.sort(BasePredicate::compareTo);
        return type.makePredicate(children, predicates, a.hasAir || b.hasAir);
    }

    private static void appendPredicates(Logic type, MultiPredicate multiPredicate, List<BasePredicate> predicates, List<MultiPredicate> children) {
        if (multiPredicate.isSingle() || multiPredicate.isType(type)) {
            predicates.addAll(multiPredicate.predicates());
            children.addAll(multiPredicate.children());
        } else {
            children.add(multiPredicate);
        }
    }


    protected enum Logic {
        OR, AND, XOR;

        public MultiPredicate makePredicate(List<MultiPredicate> children, List<BasePredicate> predicates, boolean hasAir) {
            return switch (this) {
                case OR -> new OrPredicate(children, predicates, hasAir);
                case AND -> new AndPredicate(children, predicates, hasAir);
                case XOR -> new XorPredicate(children, predicates, hasAir);
            };
        }

        public MultiPredicate makePredicate(BasePredicate predicate, boolean hasAir) {
            return makePredicate(List.of(), List.of(predicate), hasAir);
        }
    }

    public Logic getType() {
        return this.type;
    }

    public boolean isController() {
        return this.controller;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public MultiPredicate setController(final boolean controller) {
        this.controller = controller;
        return this;
    }

    @Nullable
    public MultiPredicate getParent() {
        return this.parent;
    }

    public void setParent(@Nullable final MultiPredicate parent) {
        this.parent = parent;
    }
}
