package com.gregtechceu.gtceu.api.multiblock.pattern;

import com.gregtechceu.gtceu.api.multiblock.MultiPredicate;
import com.gregtechceu.gtceu.api.multiblock.OriginOffset;
import com.gregtechceu.gtceu.api.multiblock.PredicateContext;
import com.gregtechceu.gtceu.api.multiblock.predicates.BasePredicate;
import com.gregtechceu.gtceu.api.multiblock.util.RelativeDirection;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import it.unimi.dsi.fastutil.chars.Char2ObjectMap;
import org.jetbrains.annotations.Nullable;
import java.util.*;

public class BlockPattern implements IBlockPattern {
    protected final RelativeDirection[] directions;
    // TODO: can this be removed? Multiblocks with repeatable isles can differ in sizes
    protected final int[] dimensions;
    protected final OriginOffset offset;
    protected final boolean hasStartOffset;
    protected final PatternSlice[] slices;
    protected final SliceStrategy sliceStrategy;
    protected final Char2ObjectMap<MultiPredicate> predicates;

    public BlockPattern(PatternSlice[] slices, SliceStrategy sliceStrategy, int[] dimensions, RelativeDirection[] directions, @Nullable OriginOffset offset, @Nullable OriginOffset anchorOffset, Char2ObjectMap<MultiPredicate> predicates, char centerChar) {
        this.slices = slices;
        this.sliceStrategy = sliceStrategy;
        this.dimensions = dimensions;
        this.directions = directions;
        this.predicates = predicates;
        hasStartOffset = offset != null;
        if (offset == null) {
            this.offset = new OriginOffset();
            legacyStartOffset(centerChar);
        } else {
            this.offset = offset;
        }
        if (anchorOffset != null) {
            // needs to be negative cause of double offsetting
            this.offset.move(RelativeDirection.FRONT, -anchorOffset.get(RelativeDirection.FRONT));
            this.offset.move(RelativeDirection.UP, -anchorOffset.get(RelativeDirection.UP));
            this.offset.move(RelativeDirection.LEFT, -anchorOffset.get(RelativeDirection.LEFT));
        }
    }

    private void legacyStartOffset(char center) {
        if (center == 0) return;
        for (int sliceI = 0; sliceI < dimensions[0]; sliceI++) {
            int[] res = slices[sliceI].firstInstanceOf(center);
            if (res != null) {
                moveOffset(directions[0], -sliceI);
                moveOffset(directions[1], -res[0]);
                moveOffset(directions[2], -res[1]);
                return;
            }
        }
        throw new IllegalStateException("Failed to find center symbol:  \'" + center + "\'");
    }

    @Override
    public void checkPatternFastAt(Level level, PatternState patternState, BlockPos centerPos, Direction frontFacing, Direction upwardsFacing, boolean allowsFlip) {
        if (!patternState.cache.isEmpty()) {
            boolean pass = true;
            BlockPos.MutableBlockPos mBlockPos = new BlockPos.MutableBlockPos();
            for (var entry : patternState.cache.long2ObjectEntrySet()) {
                BlockPos pos = mBlockPos.set(entry.getLongKey()).immutable();
                BlockState state = level.getBlockState(pos);
                if (state != entry.getValue().getBlockState()) {
                    pass = false;
                    break;
                }
                BlockEntity cachedBlockEntity = entry.getValue().getBlockEntity();
                if (cachedBlockEntity != null) {
                    BlockEntity be = level.getBlockEntity(pos);
                    if (be != cachedBlockEntity) {
                        pass = false;
                        break;
                    }
                }
            }
            if (pass) {
                if (patternState.hasErrors()) {
                    patternState.setState(PatternState.CheckState.INVALID_CACHED);
                } else {
                    patternState.setState(PatternState.CheckState.VALID_CACHED);
                }
                return;
            }
        }
        boolean valid = checkPatternAt(level, patternState, centerPos, frontFacing, upwardsFacing, false);
        if (valid) {
            // reaching here means the cache failed or was empty
            patternState.setState(PatternState.CheckState.VALID_UNCACHED);
            patternState.setFlipped(false);
            return;
        }
        if (allowsFlip && patternState.shouldCheckFlip()) {
            valid = checkPatternAt(level, patternState, centerPos, frontFacing, upwardsFacing, true);
        }
        if (!valid) {
            // maybe empty the block info part of the cache?
            patternState.setState(PatternState.CheckState.INVALID_UNCACHED);
            return;
        }
        patternState.setState(PatternState.CheckState.VALID_UNCACHED);
        patternState.setFlipped(true);
    }

    @Override
    public boolean checkPatternAt(Level level, PatternState patternState, BlockPos centerPos, Direction frontFacing, Direction upwardsFacing, boolean isFlipped) {
        Objects.requireNonNull(patternState, "PatternState not set");
        PredicateContext context = patternState.resetContext(true);
        // only try to clear the cache for structure checking mapping when checking the structure for unflipped
        // maybe switch to a multiblock state value instead?
        if (!isFlipped) {
            patternState.getCache().clear();
            // keep old errors if flipped
            patternState.clearErrors();
        }
        context.updateLevel(level);
        BlockPos.MutableBlockPos controllerPos = centerPos.mutable();
        // reset predicates for testing
        predicates.values().forEach(MultiPredicate::resetLogic);
        // handle slices
        sliceStrategy.setPattern(this);
        sliceStrategy.start(controllerPos, frontFacing, upwardsFacing);
        if (!sliceStrategy.check(patternState, isFlipped)) return false;
        // global min check
        for (MultiPredicate predicate : predicates.values()) {
            if (!predicate.postGlobalTest(context)) {
                context.commitSliceErrors();
                return false;
            }
        }
        patternState.clearErrors();
        return true;
    }

    /**
     * Checks a specific slice for validity
     *
     * @param controllerPos The position of the controller
     * @param frontFacing   The front facing of the controller
     * @param upwardsFacing The up facing of the controller
     * @param sliceIndex    The index of the slice, this is where the pattern is gotten from, treats repeatable slices
     *                      as only 1
     * @param sliceOffset   The offset of the slice, how much offset in sliceDir to check the blocks in world, for
     *                      example, if the first slice is repeated 2 times, sliceIndex is 1 while this is 2
     * @param flip          Whether to flip or not
     * @return True if the check passed
     */
    public boolean checkSlice(BlockPos.MutableBlockPos controllerPos, PatternState patternState, Direction frontFacing, Direction upwardsFacing, int sliceIndex, int sliceOffset, boolean flip) {
        Direction absoluteSlice = directions[0].getRelativeFacing(frontFacing, upwardsFacing, flip);
        Direction absoluteString = directions[1].getRelativeFacing(frontFacing, upwardsFacing, flip);
        Direction absoluteChar = directions[2].getRelativeFacing(frontFacing, upwardsFacing, flip);
        BlockPos.MutableBlockPos sliceStart = startPos(controllerPos, frontFacing, upwardsFacing, flip).move(absoluteSlice, sliceOffset);
        BlockPos.MutableBlockPos stringStart = sliceStart.mutable();
        BlockPos.MutableBlockPos charPos = sliceStart.mutable();
        PatternSlice slice = slices[sliceIndex];
        PredicateContext context = patternState.getContext();
        context.clearLayerCounts();
        Set<MultiPredicate> visitedPredicates = new HashSet<>();
        for (int stringIdx = 0; stringIdx < dimensions[1]; stringIdx++) {
            for (int charIdx = 0; charIdx < dimensions[2]; charIdx++) {
                context.updatePos(charPos);
                MultiPredicate multiPredicate = predicates.get(slice.charAt(stringIdx, charIdx));
                if (!multiPredicate.isAny()) patternState.updateCache();
                // state check
                BasePredicate innerPredicate = multiPredicate.getPredicateAtPos(context);
                // all predicates failed
                if (innerPredicate == null) {
                    // errors get committed in BasicSliceStrategy
                    return false;
                }
                // max count checks
                if (!innerPredicate.checkMaxCount(context)) {
                    // errors get committed in BasicSliceStrategy
                    return false;
                }
                visitedPredicates.add(multiPredicate);
                charPos.move(absoluteChar);
            }
            stringStart.move(absoluteString);
            charPos.set(stringStart);
        }
        // slice min check
        for (MultiPredicate predicate : visitedPredicates) {
            if (!predicate.postSliceTest(context)) {
                return false;
            }
        }
        return true;
    }

    public int getRepetitionCount(int sliceIndex) {
        return slices[sliceIndex].actualRepeats;
    }

    private BlockPos.MutableBlockPos startPos(BlockPos.MutableBlockPos controllerPos, Direction frontFacing, Direction upwardsFacing, boolean flip) {
        BlockPos.MutableBlockPos start = controllerPos.mutable();
        offset.apply(start, frontFacing, upwardsFacing, flip);
        return start;
    }

    public RelativeDirection[] getDirections() {
        return this.directions;
    }

    public int[] getDimensions() {
        return this.dimensions;
    }

    public OriginOffset getOffset() {
        return this.offset;
    }

    public PatternSlice[] getSlices() {
        return this.slices;
    }

    public SliceStrategy getSliceStrategy() {
        return this.sliceStrategy;
    }

    public Char2ObjectMap<MultiPredicate> getPredicates() {
        return this.predicates;
    }
}
