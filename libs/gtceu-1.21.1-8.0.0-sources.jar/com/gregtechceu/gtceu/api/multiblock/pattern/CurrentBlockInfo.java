package com.gregtechceu.gtceu.api.multiblock.pattern;

import com.gregtechceu.gtceu.GTCEu;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;
import java.util.Objects;

public class CurrentBlockInfo {
    @Nullable
    protected Level level;
    private BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
    @Nullable
    private BlockState blockState;
    @Nullable
    private BlockEntity blockEntity;
    private boolean resolvedBlockEntity;

    public BlockState retrieveCurrentBlockState() {
        if (this.blockState == null && level != null) {
            this.blockState = level.getBlockState(pos);
        }
        Objects.requireNonNull(blockState, String.format("Failed to retrieve block state at %s", pos));
        return blockState;
    }

    @Nullable
    public BlockEntity retrieveCurrentBlockEntity() {
        BlockState state = retrieveCurrentBlockState();
        if (!state.hasBlockEntity()) {
            return null;
        }
        if (blockEntity == null && !resolvedBlockEntity && level != null) {
            blockEntity = level.getBlockEntity(pos);
            resolvedBlockEntity = true;
        }
        return blockEntity;
    }

    public void setCurrentPos(BlockPos pos) {
        this.pos.set(pos);
        updateStateAndEntity();
    }

    public BlockPos getBlockPos() {
        return pos;
    }

    private void updateStateAndEntity() {
        if (level == null) {
            GTCEu.LOGGER.error("Level is null in CurrentBlockInfo");
            return;
        }
        blockState = level.getBlockState(pos);
        blockEntity = level.getBlockEntity(pos);
        resolvedBlockEntity = true;
    }

    public CurrentBlockInfo shallowCopy() {
        CurrentBlockInfo ret = new CurrentBlockInfo();
        ret.level = level;
        ret.pos = pos;
        ret.blockState = blockState;
        ret.blockEntity = blockEntity;
        return ret;
    }

    public void setLevel(@Nullable final Level level) {
        this.level = level;
    }

    @Nullable
    public Level getLevel() {
        return this.level;
    }

    public BlockPos.MutableBlockPos getPos() {
        return this.pos;
    }

    @Nullable
    public BlockState getBlockState() {
        return this.blockState;
    }

    @Nullable
    public BlockEntity getBlockEntity() {
        return this.blockEntity;
    }
}
