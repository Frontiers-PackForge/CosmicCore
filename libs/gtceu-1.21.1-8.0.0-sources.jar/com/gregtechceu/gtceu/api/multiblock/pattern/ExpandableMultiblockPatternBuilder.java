package com.gregtechceu.gtceu.api.multiblock.pattern;

import com.gregtechceu.gtceu.api.multiblock.MultiPredicate;
import com.gregtechceu.gtceu.api.multiblock.util.RelativeDirection;
import it.unimi.dsi.fastutil.chars.Char2ObjectMap;
import it.unimi.dsi.fastutil.chars.Char2ObjectOpenHashMap;
import org.jetbrains.annotations.Nullable;
import java.util.Objects;
import static com.gregtechceu.gtceu.api.multiblock.pattern.PatternBuilderUtils.checkNullPredicates;

public class ExpandableMultiblockPatternBuilder {
    @Nullable
    protected ExpandablePattern.BoundsProvider boundsProvider;
    @Nullable
    protected ExpandablePattern.BoundsConstraintProvider constraintProvider;
    @Nullable
    protected ExpandablePattern.PredicateProvider predicateProvider;
    protected final RelativeDirection[] directions = new RelativeDirection[3];
    private final Char2ObjectMap<MultiPredicate> symbolMap = new Char2ObjectOpenHashMap<>();

    private ExpandableMultiblockPatternBuilder(RelativeDirection aisleDir, RelativeDirection stringDir, RelativeDirection charDir) {
        directions[0] = aisleDir;
        directions[1] = stringDir;
        directions[2] = charDir;
        RelativeDirection.validateFacingsArray(directions);
    }

    public static ExpandableMultiblockPatternBuilder start(RelativeDirection aisleDir, RelativeDirection stringDir, RelativeDirection charDir) {
        return new ExpandableMultiblockPatternBuilder(aisleDir, stringDir, charDir);
    }

    public static ExpandableMultiblockPatternBuilder start() {
        return new ExpandableMultiblockPatternBuilder(RelativeDirection.BACK, RelativeDirection.UP, RelativeDirection.RIGHT);
    }

    public ExpandableMultiblockPatternBuilder where(char symbol, MultiPredicate predicate) {
        this.symbolMap.put(symbol, predicate);
        return this;
    }

    public ExpandablePattern build() {
        Objects.requireNonNull(boundsProvider, "Bound function is null");
        Objects.requireNonNull(predicateProvider, "Predicate function is null");
        checkNullPredicates(symbolMap);
        ExpandablePattern pattern = new ExpandablePattern(boundsProvider, predicateProvider, symbolMap, directions);
        if (constraintProvider != null) {
            pattern.setBoundsConstraints(constraintProvider);
        }
        return pattern;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ExpandableMultiblockPatternBuilder boundsProvider(@Nullable final ExpandablePattern.BoundsProvider boundsProvider) {
        this.boundsProvider = boundsProvider;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ExpandableMultiblockPatternBuilder constraintProvider(@Nullable final ExpandablePattern.BoundsConstraintProvider constraintProvider) {
        this.constraintProvider = constraintProvider;
        return this;
    }

    /**
     * @return {@code this}.
     */
    @org.jetbrains.annotations.NotNull
    public ExpandableMultiblockPatternBuilder predicateProvider(@Nullable final ExpandablePattern.PredicateProvider predicateProvider) {
        this.predicateProvider = predicateProvider;
        return this;
    }
}
