package com.gregtechceu.gtceu.api.multiblock.pattern;

import com.gregtechceu.gtceu.api.multiblock.MultiPredicate;
import com.gregtechceu.gtceu.api.multiblock.OriginOffset;
import com.gregtechceu.gtceu.api.multiblock.PredicateContext;
import com.gregtechceu.gtceu.api.multiblock.predicates.BasePredicate;
import com.gregtechceu.gtceu.api.multiblock.util.RelativeDirection;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntIntPair;
import it.unimi.dsi.fastutil.ints.IntList;
import org.jetbrains.annotations.Nullable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.BiFunction;

public class ExpandablePattern implements IBlockPattern {

    @FunctionalInterface
    public interface BoundsProvider {
        @Nullable
        IntList apply(Level level, BlockPos.MutableBlockPos pos, Direction front, Direction upwards);

        BoundsProvider EMPTY = (l, p, f, u) -> new IntArrayList(new int[] {0, 0, 0, 0, 0, 0});
    }


    @FunctionalInterface
    public interface BoundsConstraintProvider {
        List<IntIntPair> apply();
    }

    protected final BoundsProvider boundsProvider;
    @Nullable
    protected BoundsConstraintProvider boundsConstraints = null;
    protected final BiFunction<BlockPos.MutableBlockPos, List<Integer>, MultiPredicate> predicateProvider;
    protected final OriginOffset offset = new OriginOffset();
    protected final RelativeDirection[] directions;

    public ExpandablePattern(BoundsProvider boundsProvider, BiFunction<BlockPos.MutableBlockPos, List<Integer>, MultiPredicate> predicateProvider, RelativeDirection[] directions) {
        this.boundsProvider = boundsProvider;
        this.predicateProvider = predicateProvider;
        this.directions = directions;
    }

    @Override
    public void checkPatternFastAt(Level level, PatternState patternState, BlockPos centerPos, Direction frontFacing, Direction upwardsFacing, boolean allowsFlip) {
        if (!patternState.getCache().isEmpty()) {
            boolean pass = true;
            BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
            for (var entry : patternState.getCache().long2ObjectEntrySet()) {
                pos.set(entry.getLongKey());
                BlockState state = level.getBlockState(pos);
                if (state != entry.getValue().getBlockState()) {
                    pass = false;
                    break;
                }
                BlockEntity cachedBE = entry.getValue().getBlockEntity();
                if (cachedBE != null) {
                    BlockEntity be = level.getBlockEntity(pos);
                    if (be != cachedBE) {
                        pass = false;
                        break;
                    }
                }
            }
            if (pass) {
                if (patternState.hasErrors()) {
                    patternState.setState(PatternState.CheckState.INVALID_CACHED);
                } else {
                    patternState.setState(PatternState.CheckState.VALID_CACHED);
                }
                return;
            }
        }
        patternState.setFlipped(false);
        boolean valid = checkPatternAt(level, patternState, centerPos, frontFacing, upwardsFacing, false);
        if (valid) {
            patternState.setState(PatternState.CheckState.VALID_UNCACHED);
            return;
        }
        if (allowsFlip && patternState.shouldCheckFlip()) {
            valid = checkPatternAt(level, patternState, centerPos, frontFacing, upwardsFacing, true);
        }
        if (!valid) {
            // maybe empty the block info part of the cache?
            patternState.setState(PatternState.CheckState.INVALID_UNCACHED);
            return;
        }
        patternState.setState(PatternState.CheckState.VALID_UNCACHED);
        patternState.setFlipped(true);
    }

    @Override
    public boolean checkPatternAt(Level level, PatternState patternState, BlockPos centerPos, Direction frontFacing, Direction upwardsFacing, boolean isFlipped) {
        List<Integer> bounds = boundsProvider.apply(level, centerPos.mutable(), frontFacing, upwardsFacing);
        if (bounds.isEmpty()) return false;
        PredicateContext context = patternState.resetContext(false);
        if (!isFlipped) {
            patternState.clearErrors();
        }
        BlockPos.MutableBlockPos negCorner = new BlockPos.MutableBlockPos();
        BlockPos.MutableBlockPos posCorner = new BlockPos.MutableBlockPos();
        Direction[] absolutes = new Direction[3];
        for (int i = 0; i < 3; i++) {
            RelativeDirection selected = directions[i];
            absolutes[i] = selected.getRelativeFacing(frontFacing, upwardsFacing, isFlipped);
            if (i == 0) {
                negCorner.setX(-bounds.get(selected.oppositeOrdinal()));
                posCorner.setX(bounds.get(selected.ordinal()));
            } else if (i == 1) {
                negCorner.setY(-bounds.get(selected.oppositeOrdinal()));
                posCorner.setY(bounds.get(selected.ordinal()));
            } else {
                negCorner.setZ(-bounds.get(selected.oppositeOrdinal()));
                posCorner.setZ(bounds.get(selected.ordinal()));
            }
        }
        context.updateLevel(level);
        BlockPos.MutableBlockPos translation = centerPos.mutable();
        // SOUTH, UP, EAST means point is +z, line is +y, plane is +x. this basically means the x val of the iter is
        // aisle count, y is str count, and z is char count.
        Set<MultiPredicate> visited = new HashSet<>();
        for (var pos : BlockPos.betweenClosed(negCorner, posCorner)) {
            BlockPos.MutableBlockPos mPos = pos.mutable();
            MultiPredicate multiPredicate = predicateProvider.apply(mPos, bounds);
            if (visited.add(multiPredicate)) {
                multiPredicate.resetLogic();
            }
            // this basically reshuffles the coordinates into absolute form from relative form
            mPos.set(BlockPos.ZERO).move(absolutes[0], pos.getX()).move(absolutes[1], pos.getY()).move(absolutes[2], pos.getZ());
            // translate from the origin to the center
            mPos = mPos.offset(translation).mutable();
            context.updatePos(mPos);
            if (!multiPredicate.isAny()) patternState.updateCache();
            // state check
            BasePredicate innerPredicate = multiPredicate.getPredicateAtPos(context);
            // all predicates failed
            if (innerPredicate == null) {
                context.commitSliceErrors(); // this is actually global errors, not slice
                return false;
            }
            // max count checks
            if (!innerPredicate.checkMaxCount(context)) {
                context.commitSliceErrors(); // this is actually global errors, not slice
                return false;
            }
        }
        for (MultiPredicate multiPredicate : visited) {
            if (!multiPredicate.postGlobalTest(context)) {
                context.commitSliceErrors();
                return false;
            }
        }
        patternState.clearErrors();
        return true;
    }

    @Nullable
    public BoundsConstraintProvider getBoundsConstraints() {
        return this.boundsConstraints;
    }

    public void setBoundsConstraints(@Nullable final BoundsConstraintProvider boundsConstraints) {
        this.boundsConstraints = boundsConstraints;
    }

    public BiFunction<BlockPos.MutableBlockPos, List<Integer>, MultiPredicate> getPredicateProvider() {
        return this.predicateProvider;
    }

    public OriginOffset getOffset() {
        return this.offset;
    }

    public RelativeDirection[] getDirections() {
        return this.directions;
    }
}
