package com.gregtechceu.gtceu.api.multiblock.pattern;

import com.gregtechceu.gtceu.api.machine.multiblock.MultiblockControllerMachine;
import com.gregtechceu.gtceu.api.multiblock.MultiblockWorldSavedData;
import com.gregtechceu.gtceu.api.multiblock.error.PatternError;
import com.gregtechceu.gtceu.api.multiblock.predicates.BasePredicate;
import com.gregtechceu.gtceu.api.multiblock.util.BlockInfo;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.BlockState;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import java.util.List;
/*
 * Contains vital information to an instanced version of a structure pattern.
 */
public class PatternState {
    @Nullable
    protected BlockPos controllerPos;
    @Nullable
    protected MultiblockControllerMachine controller;
    protected boolean isFormed = false;
    protected volatile boolean isFlipped = false;
    protected boolean actualFlipped = false;
    protected boolean shouldUpdate = true;
    @Nullable
    protected List<PatternError> errors;
    protected CheckState state = CheckState.UNINITIALIZED;
    protected CurrentBlockInfo currentBlockInfo = new CurrentBlockInfo();
    protected final Object2IntMap<BasePredicate> globalCount = new Object2IntOpenHashMap<>();
    protected final Object2IntMap<BasePredicate> layerCount = new Object2IntOpenHashMap<>();
    protected final Long2ObjectMap<BlockInfo> cache = new Long2ObjectOpenHashMap<>();

    public void setController(MultiblockControllerMachine controller, BlockPos controllerPos) {
        this.controller = controller;
        this.controllerPos = controllerPos;
    }

    @ApiStatus.Internal
    public void setFlipped(boolean flipped) {
        isFlipped = flipped;
    }

    public boolean shouldUpdate() {
        return shouldUpdate;
    }

    public boolean hasErrors() {
        return errors != null;
    }

    public void setError(@Nullable PatternError error) {
        this.errors = error != null ? List.of(error) : null;
    }

    public void setErrors(@Nullable List<PatternError> error) {
        this.errors = error;
    }

    public void onBlockStateChanged(BlockPos pos, BlockState oldState, BlockState newState) {
        if (!(currentBlockInfo.getLevel() instanceof ServerLevel serverLevel)) return;
        if (pos.equals(controllerPos)) {
            if (controller != null && !newState.is(controller.self().getBlockState().getBlock())) {
                controller.invalidateStructure(MultiblockControllerMachine.DEFAULT_STRUCTURE);
                MultiblockWorldSavedData.getOrCreate(serverLevel).removeMapping(this);
            }
        } else 
        // block other than controller changed
        if (controller != null) {
            // if the blocks that changed where active blocks changing state, don't bother rechecking
            if ((oldState.getBlock() == newState.getBlock()) && newState.getBlock() instanceof IStructureChangeIgnored && oldState.getBlock() instanceof IStructureChangeIgnored) {
                return;
            }
            for (var name : controller.getStructureNames()) {
                PatternState patternState = controller.checkStructurePattern(name);
                if (!patternState.hasErrors()) {
                    controller.formStructure(name);
                } else {
                    controller.invalidateStructure(name);
                    if (name.equals(MultiblockControllerMachine.DEFAULT_STRUCTURE)) {
                        MultiblockWorldSavedData.getOrCreate(serverLevel).removeMapping(this);
                        controller.checkAndFormStructure();
                    }
                }
            }
        }
    }


    public enum CheckState {
        /**
         * The cache doesn't match with the structure's data. The structure has been rechecked from scratch, is valid,
         * and the cache is now populated.
         */
        VALID_UNCACHED(true, false), /**
         * The cache matches the structure's data.
         */
        VALID_CACHED(true, true), /**
         * The cache doesn't match with the structure's data. The structure has been rechecked from scratch, is invalid,
         * and the cache is now empty.
         */
        INVALID_CACHED(false, true), /**
         * The cache is empty. The structure has been rechecked from scratch and is invalid, the cache remains empty.
         */
        INVALID_UNCACHED(false, false), /**
         * The Check State is not initialized, structure checking failed
         */
        UNINITIALIZED(false, false);
        private final boolean valid;
        private final boolean cached;

        CheckState(boolean valid, boolean cached) {
            this.valid = valid;
            this.cached = cached;
        }

        public boolean isValid() {
            return this.valid;
        }

        public boolean isCached() {
            return this.cached;
        }
    }

    @Nullable
    public BlockPos getControllerPos() {
        return this.controllerPos;
    }

    @Nullable
    public MultiblockControllerMachine getController() {
        return this.controller;
    }

    public boolean isFormed() {
        return this.isFormed;
    }

    public void setFormed(final boolean isFormed) {
        this.isFormed = isFormed;
    }

    public boolean isFlipped() {
        return this.isFlipped;
    }

    public void setActualFlipped(final boolean actualFlipped) {
        this.actualFlipped = actualFlipped;
    }

    public boolean isActualFlipped() {
        return this.actualFlipped;
    }

    public void setShouldUpdate(final boolean shouldUpdate) {
        this.shouldUpdate = shouldUpdate;
    }

    @Nullable
    public List<PatternError> getErrors() {
        return this.errors;
    }

    public void setState(final CheckState state) {
        this.state = state;
    }

    public CheckState getState() {
        return this.state;
    }

    public CurrentBlockInfo getCurrentBlockInfo() {
        return this.currentBlockInfo;
    }

    public Long2ObjectMap<BlockInfo> getCache() {
        return this.cache;
    }
}
