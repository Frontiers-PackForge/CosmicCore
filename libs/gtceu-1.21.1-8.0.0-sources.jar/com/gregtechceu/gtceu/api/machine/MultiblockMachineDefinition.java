package com.gregtechceu.gtceu.api.machine;

import com.gregtechceu.gtceu.api.machine.multiblock.MultiblockControllerMachine;
import com.gregtechceu.gtceu.api.machine.multiblock.part.MultiblockPartMachine;
import com.gregtechceu.gtceu.api.multiblock.pattern.IBlockPattern;
import com.gregtechceu.gtceu.utils.memoization.GTMemoizer;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import brachy.modularui.api.widget.IWidget;
import brachy.modularui.value.sync.PanelSyncManager;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ReferenceOpenHashMap;
import org.apache.commons.lang3.function.TriFunction;
import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

public class MultiblockMachineDefinition extends MachineDefinition {
    private final boolean generator;
    private final Map<String, Supplier<IBlockPattern>> structurePatterns;
    private final boolean allowFlip;
    private final boolean renderXEIPreview;
    private final boolean renderWorldPreview;
    private final Supplier<ItemStack[]> recoveryItems;
    private final Function<MultiblockControllerMachine, Comparator<MultiblockPartMachine>> partSorter;
    private final TriFunction<MultiblockControllerMachine, MultiblockPartMachine, Direction, BlockState> partAppearance;
    private final BiFunction<MultiblockControllerMachine, PanelSyncManager, List<IWidget>> additionalDisplay;

    public MultiblockMachineDefinition(ResourceLocation id, Properties properties) {
        super(id, properties);
        this.generator = properties.generator;
        Map<String, Supplier<IBlockPattern>> structurePatterns = new Object2ObjectOpenHashMap<>();
        if (properties.patterns().isEmpty()) {
            throw new IllegalStateException("Missing default structure pattern for " + getName());
        }
        for (Map.Entry<String, Function<MultiblockMachineDefinition, IBlockPattern>> entry : properties.patterns.entrySet()) {
            structurePatterns.put(entry.getKey(), GTMemoizer.memoize(() -> entry.getValue().apply(this)));
        }
        this.structurePatterns = Collections.unmodifiableMap(structurePatterns);
        this.allowFlip = properties.allowFlip();
        this.renderXEIPreview = properties.renderMultiblockXEIPreview;
        this.renderWorldPreview = properties.renderMultiblockWorldPreview;
        this.recoveryItems = () -> properties.recoveryItems.stream().map(Supplier::get).flatMap(Arrays::stream).toArray(ItemStack[]::new);
        this.partSorter = GTMemoizer.memoizeFunctionWeakIdent(properties.partSorter());
        this.partAppearance = properties.partAppearance();
        this.additionalDisplay = properties.additionalDisplay();
    }


    public static class Properties extends MachineDefinition.Properties {
        private boolean generator = false;
        private final Map<String, Function<MultiblockMachineDefinition, IBlockPattern>> patterns = new Object2ReferenceOpenHashMap<>();
        private boolean allowFlip = true;
        private final List<Supplier<ItemStack[]>> recoveryItems = new ArrayList<>();
        private Function<MultiblockControllerMachine, Comparator<MultiblockPartMachine>> partSorter = c -> (a, b) -> 0;
        private TriFunction<MultiblockControllerMachine, MultiblockPartMachine, Direction, BlockState> partAppearance = (controller, part, side) -> controller.getDefinition().getAppearance().get();
        private boolean renderMultiblockWorldPreview = true;
        private boolean renderMultiblockXEIPreview = true;
        private BiFunction<MultiblockControllerMachine, PanelSyncManager, List<IWidget>> additionalDisplay = (m, sm) -> Collections.emptyList();

        public boolean generator() {
            return this.generator;
        }

        public Map<String, Function<MultiblockMachineDefinition, IBlockPattern>> patterns() {
            return this.patterns;
        }

        public boolean allowFlip() {
            return this.allowFlip;
        }

        public List<Supplier<ItemStack[]>> recoveryItems() {
            return this.recoveryItems;
        }

        public Function<MultiblockControllerMachine, Comparator<MultiblockPartMachine>> partSorter() {
            return this.partSorter;
        }

        public TriFunction<MultiblockControllerMachine, MultiblockPartMachine, Direction, BlockState> partAppearance() {
            return this.partAppearance;
        }

        public boolean renderMultiblockWorldPreview() {
            return this.renderMultiblockWorldPreview;
        }

        public boolean renderMultiblockXEIPreview() {
            return this.renderMultiblockXEIPreview;
        }

        public BiFunction<MultiblockControllerMachine, PanelSyncManager, List<IWidget>> additionalDisplay() {
            return this.additionalDisplay;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MultiblockMachineDefinition.Properties generator(final boolean generator) {
            this.generator = generator;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MultiblockMachineDefinition.Properties allowFlip(final boolean allowFlip) {
            this.allowFlip = allowFlip;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MultiblockMachineDefinition.Properties partSorter(final Function<MultiblockControllerMachine, Comparator<MultiblockPartMachine>> partSorter) {
            this.partSorter = partSorter;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MultiblockMachineDefinition.Properties partAppearance(final TriFunction<MultiblockControllerMachine, MultiblockPartMachine, Direction, BlockState> partAppearance) {
            this.partAppearance = partAppearance;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MultiblockMachineDefinition.Properties renderMultiblockWorldPreview(final boolean renderMultiblockWorldPreview) {
            this.renderMultiblockWorldPreview = renderMultiblockWorldPreview;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MultiblockMachineDefinition.Properties renderMultiblockXEIPreview(final boolean renderMultiblockXEIPreview) {
            this.renderMultiblockXEIPreview = renderMultiblockXEIPreview;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MultiblockMachineDefinition.Properties additionalDisplay(final BiFunction<MultiblockControllerMachine, PanelSyncManager, List<IWidget>> additionalDisplay) {
            this.additionalDisplay = additionalDisplay;
            return this;
        }
    }

    public boolean isGenerator() {
        return this.generator;
    }

    public Map<String, Supplier<IBlockPattern>> getStructurePatterns() {
        return this.structurePatterns;
    }

    public boolean isAllowFlip() {
        return this.allowFlip;
    }

    public boolean isRenderXEIPreview() {
        return this.renderXEIPreview;
    }

    public boolean isRenderWorldPreview() {
        return this.renderWorldPreview;
    }

    public Supplier<ItemStack[]> getRecoveryItems() {
        return this.recoveryItems;
    }

    public Function<MultiblockControllerMachine, Comparator<MultiblockPartMachine>> getPartSorter() {
        return this.partSorter;
    }

    public TriFunction<MultiblockControllerMachine, MultiblockPartMachine, Direction, BlockState> getPartAppearance() {
        return this.partAppearance;
    }

    public BiFunction<MultiblockControllerMachine, PanelSyncManager, List<IWidget>> getAdditionalDisplay() {
        return this.additionalDisplay;
    }
}
