package com.gregtechceu.gtceu.api.machine;

import com.gregtechceu.gtceu.api.machine.multiblock.MultiblockControllerMachine;
import com.gregtechceu.gtceu.api.machine.multiblock.part.MultiblockPartMachine;
import com.gregtechceu.gtceu.api.multiblock.pattern.IBlockPattern;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import brachy.modularui.api.widget.IWidget;
import brachy.modularui.value.sync.PanelSyncManager;
import org.apache.commons.lang3.function.TriFunction;
import org.jetbrains.annotations.Nullable;
import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

public class MultiblockMachineDefinition extends MachineDefinition {
    private boolean generator;
    private Map<String, Supplier<IBlockPattern>> structurePatterns = new HashMap<>();
    private boolean allowFlip;
    private boolean renderXEIPreview;
    @Nullable
    private Supplier<ItemStack[]> recoveryItems;
    private Function<MultiblockControllerMachine, Comparator<MultiblockPartMachine>> partSorter;
    private TriFunction<MultiblockControllerMachine, MultiblockPartMachine, Direction, BlockState> partAppearance;
    private BiFunction<MultiblockControllerMachine, PanelSyncManager, List<IWidget>> additionalDisplay;

    public MultiblockMachineDefinition(ResourceLocation id) {
        super(id);
    }

    public void setPattern(String structureName, Supplier<IBlockPattern> pattern) {
        structurePatterns.put(structureName, pattern);
    }

    public boolean isGenerator() {
        return this.generator;
    }

    public void setGenerator(final boolean generator) {
        this.generator = generator;
    }

    public Map<String, Supplier<IBlockPattern>> getStructurePatterns() {
        return this.structurePatterns;
    }

    public boolean isAllowFlip() {
        return this.allowFlip;
    }

    public void setAllowFlip(final boolean allowFlip) {
        this.allowFlip = allowFlip;
    }

    public boolean isRenderXEIPreview() {
        return this.renderXEIPreview;
    }

    public void setRenderXEIPreview(final boolean renderXEIPreview) {
        this.renderXEIPreview = renderXEIPreview;
    }

    public void setRecoveryItems(@Nullable final Supplier<ItemStack[]> recoveryItems) {
        this.recoveryItems = recoveryItems;
    }

    @Nullable
    public Supplier<ItemStack[]> getRecoveryItems() {
        return this.recoveryItems;
    }

    public void setPartSorter(final Function<MultiblockControllerMachine, Comparator<MultiblockPartMachine>> partSorter) {
        this.partSorter = partSorter;
    }

    public Function<MultiblockControllerMachine, Comparator<MultiblockPartMachine>> getPartSorter() {
        return this.partSorter;
    }

    public TriFunction<MultiblockControllerMachine, MultiblockPartMachine, Direction, BlockState> getPartAppearance() {
        return this.partAppearance;
    }

    public void setPartAppearance(final TriFunction<MultiblockControllerMachine, MultiblockPartMachine, Direction, BlockState> partAppearance) {
        this.partAppearance = partAppearance;
    }

    public BiFunction<MultiblockControllerMachine, PanelSyncManager, List<IWidget>> getAdditionalDisplay() {
        return this.additionalDisplay;
    }

    public void setAdditionalDisplay(final BiFunction<MultiblockControllerMachine, PanelSyncManager, List<IWidget>> additionalDisplay) {
        this.additionalDisplay = additionalDisplay;
    }
}
