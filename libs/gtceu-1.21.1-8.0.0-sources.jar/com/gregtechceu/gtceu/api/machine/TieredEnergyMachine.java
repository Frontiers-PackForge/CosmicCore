package com.gregtechceu.gtceu.api.machine;

import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.blockentity.BlockEntityCreationInfo;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableEnergyContainer;
import com.gregtechceu.gtceu.api.sync_system.annotations.SaveField;
import com.gregtechceu.gtceu.api.sync_system.annotations.SyncToClient;
import com.gregtechceu.gtceu.common.machine.trait.EnvironmentalExplosionTrait;
import net.minecraft.util.Mth;
import java.util.function.Function;

/**
 * A singleblock tiered machine with an energy container.
 */
public class TieredEnergyMachine extends TieredMachine {
    @SaveField
    @SyncToClient
    public final NotifiableEnergyContainer energyContainer;
    protected final EnvironmentalExplosionTrait environmentalExplosionTrait;

    public TieredEnergyMachine(BlockEntityCreationInfo info, int tier, NotifiableEnergyContainer energyContainer) {
        super(info, tier);
        this.energyContainer = attachTrait(energyContainer);
        environmentalExplosionTrait = attachTrait(new EnvironmentalExplosionTrait(tier, tier * 10, () -> energyContainer.getEnergyStored() > 0));
    }

    public TieredEnergyMachine(BlockEntityCreationInfo info, int tier, Function<TieredEnergyMachine, NotifiableEnergyContainer> energyContainer) {
        super(info, tier);
        this.energyContainer = attachTrait(energyContainer.apply(this));
        environmentalExplosionTrait = attachTrait(new EnvironmentalExplosionTrait(tier, tier * 10, () -> this.energyContainer.getEnergyStored() > 0));
    }

    public TieredEnergyMachine(BlockEntityCreationInfo info, int tier) {
        super(info, tier);
        long tierVoltage = GTValues.V[tier];
        if (isEnergyEmitter()) {
            energyContainer = attachTrait(NotifiableEnergyContainer.emitterContainer(tierVoltage * 64L, tierVoltage, getMaxInputOutputAmperage()));
        } else {
            energyContainer = attachTrait(NotifiableEnergyContainer.receiverContainer(tierVoltage * 64L, tierVoltage, getMaxInputOutputAmperage()));
        }
        environmentalExplosionTrait = attachTrait(new EnvironmentalExplosionTrait(tier, tier * 10, () -> energyContainer.getEnergyStored() > 0));
    }

    //////////////////////////////////////
    // ********** MISC ***********//
    //////////////////////////////////////
    @Override
    public int getAnalogOutputSignal() {
        long energyStored = energyContainer.getEnergyStored();
        long energyCapacity = energyContainer.getEnergyCapacity();
        float f = energyCapacity == 0L ? 0.0F : energyStored / (energyCapacity * 1.0F);
        return Mth.floor(f * 14.0F) + (energyStored > 0 ? 1 : 0);
    }

    /**
     * Determines max input or output amperage used by this machine
     * if emitter, it determines size of energy packets it will emit at once
     * if receiver, it determines max input energy per request
     *
     * @return max amperage received or emitted by this machine
     */
    protected long getMaxInputOutputAmperage() {
        return 1L;
    }

    /**
     * Determines if this machine is in energy receiver or emitter mode
     *
     * @return true if machine emits energy to network, false it it accepts energy from network
     */
    protected boolean isEnergyEmitter() {
        return false;
    }

    public EnvironmentalExplosionTrait getEnvironmentalExplosionTrait() {
        return this.environmentalExplosionTrait;
    }
}
