package com.gregtechceu.gtceu.api.machine.trait.hpca;

import com.gregtechceu.gtceu.api.machine.MetaMachine;

public class HPCACoolantProviderTrait extends HPCAComponentTrait {
    private final int coolingAmount;
    private final int maxCoolantPerTick;
    private final boolean isActiveCooler;

    public HPCACoolantProviderTrait(MetaMachine machine, int upkeepEUt, int maxEUt, boolean canBeDamaged, boolean allowBridging, int coolingAmount, int maxCoolantPerTick, boolean isActiveCooler) {
        super(machine, upkeepEUt, maxEUt, canBeDamaged, allowBridging);
        this.coolingAmount = coolingAmount;
        this.maxCoolantPerTick = maxCoolantPerTick;
        this.isActiveCooler = isActiveCooler;
    }

    public int getCoolingAmount() {
        return this.coolingAmount;
    }

    public int getMaxCoolantPerTick() {
        return this.maxCoolantPerTick;
    }

    public boolean isActiveCooler() {
        return this.isActiveCooler;
    }
}
