package com.gregtechceu.gtceu.api.machine.trait;

import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.multiblock.CleanroomType;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import java.util.Set;

public class CleanroomProviderTrait extends MachineTrait {
    public static final MachineTraitType<CleanroomProviderTrait> TYPE = new MachineTraitType<>(CleanroomProviderTrait.class, false);
    private Set<CleanroomType> providedTypes;
    private boolean isActive;

    public CleanroomProviderTrait(MetaMachine machine, Set<CleanroomType> providedTypes) {
        super(machine);
        this.providedTypes = new ObjectOpenHashSet<>(providedTypes);
        this.isActive = false;
    }

    @Override
    public MachineTraitType<CleanroomProviderTrait> getTraitType() {
        return TYPE;
    }

    public CleanroomProviderTrait(MetaMachine machine) {
        this(machine, Set.of(CleanroomType.CLEANROOM));
    }

    public Set<CleanroomType> getProvidedTypes() {
        return this.providedTypes;
    }

    public void setProvidedTypes(final Set<CleanroomType> providedTypes) {
        this.providedTypes = providedTypes;
    }

    public boolean isActive() {
        return this.isActive;
    }

    public void setActive(final boolean isActive) {
        this.isActive = isActive;
    }
}
