package com.gregtechceu.gtceu.api.machine;

import com.gregtechceu.gtceu.GTCEu;
import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.blockentity.BlockEntityCreationInfo;
import com.gregtechceu.gtceu.api.capability.recipe.*;
import com.gregtechceu.gtceu.api.machine.feature.*;
import com.gregtechceu.gtceu.api.machine.trait.*;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.api.sync_system.annotations.SaveField;
import com.gregtechceu.gtceu.api.sync_system.annotations.SyncToClient;
import com.gregtechceu.gtceu.utils.GTUtil;
import com.gregtechceu.gtceu.utils.ISubscription;
import it.unimi.dsi.fastutil.ints.Int2IntFunction;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.VisibleForTesting;
import java.util.*;
import java.util.function.Function;

public abstract class WorkableTieredMachine extends TieredEnergyMachine implements IRecipeLogicMachine, IMufflableMachine, IOverclockMachine {
    @SaveField
    @SyncToClient
    public final RecipeLogic recipeLogic;
    private GTRecipeType[] recipeTypes;
    @SaveField
    public int activeRecipeType;
    protected final CleanroomReceiverTrait cleanroomReceiver;
    @SaveField
    public final NotifiableItemStackHandler importItems;
    @SaveField
    public final NotifiableItemStackHandler exportItems;
    @SaveField
    public final NotifiableFluidTank importFluids;
    @SaveField
    public final NotifiableFluidTank exportFluids;
    @SaveField
    public final NotifiableComputationContainer importComputation;
    @SaveField
    public final NotifiableComputationContainer exportComputation;
    protected final Map<IO, List<RecipeHandlerList>> capabilitiesProxy;
    protected final Map<IO, Map<RecipeCapability<?>, List<IRecipeHandler<?>>>> capabilitiesFlat;
    @SaveField
    protected int overclockTier;
    protected final List<ISubscription> traitSubscriptions;
    @SaveField
    @SyncToClient
    protected boolean isMuffled;
    protected boolean previouslyMuffled = true;

    public WorkableTieredMachine(BlockEntityCreationInfo info, int tier, Function<WorkableTieredMachine, RecipeLogic> recipeLogicSupplier, int importSlots, int exportSlots, int fluidImportSlots, int fluidExportSlots, Int2IntFunction tankScalingFunction) {
        super(info, tier);
        this.overclockTier = getMaxOverclockTier();
        this.recipeTypes = getDefinition().getRecipeTypes();
        this.activeRecipeType = 0;
        this.capabilitiesProxy = new EnumMap<>(IO.class);
        this.capabilitiesFlat = new EnumMap<>(IO.class);
        this.traitSubscriptions = new ArrayList<>();
        this.cleanroomReceiver = new CleanroomReceiverTrait(this);
        this.recipeLogic = recipeLogicSupplier.apply(this);
        this.importItems = new NotifiableItemStackHandler(this, importSlots, IO.IN, IO.BOTH);
        this.exportItems = new NotifiableItemStackHandler(this, exportSlots, IO.OUT);
        this.importFluids = new NotifiableFluidTank(this, fluidImportSlots, tankScalingFunction.applyAsInt(getTier()), IO.IN, IO.BOTH);
        this.exportFluids = new NotifiableFluidTank(this, fluidExportSlots, tankScalingFunction.applyAsInt(getTier()), IO.OUT);
        this.importComputation = new NotifiableComputationContainer(this, IO.IN, true);
        this.exportComputation = new NotifiableComputationContainer(this, IO.OUT, false);
    }

    public WorkableTieredMachine(BlockEntityCreationInfo info, int tier, Int2IntFunction tankScalingFunction) {
        super(info, tier);
        this.overclockTier = getMaxOverclockTier();
        this.recipeTypes = getDefinition().getRecipeTypes();
        this.activeRecipeType = 0;
        this.capabilitiesProxy = new EnumMap<>(IO.class);
        this.capabilitiesFlat = new EnumMap<>(IO.class);
        this.traitSubscriptions = new ArrayList<>();
        this.cleanroomReceiver = new CleanroomReceiverTrait(this);
        this.recipeLogic = new RecipeLogic(this);
        this.importItems = new NotifiableItemStackHandler(this, getRecipeType().getMaxInputs(ItemRecipeCapability.CAP), IO.IN);
        this.exportItems = new NotifiableItemStackHandler(this, getRecipeType().getMaxOutputs(ItemRecipeCapability.CAP), IO.OUT);
        this.importFluids = new NotifiableFluidTank(this, getRecipeType().getMaxInputs(FluidRecipeCapability.CAP), tankScalingFunction.applyAsInt(getTier()), IO.IN);
        this.exportFluids = new NotifiableFluidTank(this, getRecipeType().getMaxOutputs(FluidRecipeCapability.CAP), tankScalingFunction.applyAsInt(getTier()), IO.OUT);
        this.importComputation = new NotifiableComputationContainer(this, IO.IN, true);
        this.exportComputation = new NotifiableComputationContainer(this, IO.OUT, false);
    }

    //////////////////////////////////////
    // ***** Initialization ******//
    //////////////////////////////////////
    @Override
    public void onLoad() {
        super.onLoad();
        // attach self traits
        Map<IO, List<IRecipeHandler<?>>> ioTraits = new EnumMap<>(IO.class);
        for (MachineTrait trait : traitHolder.getAllTraits()) {
            if (trait instanceof IRecipeHandlerTrait<?> handlerTrait) {
                ioTraits.computeIfAbsent(handlerTrait.getHandlerIO(), i -> new ArrayList<>()).add(handlerTrait);
            }
        }
        for (var entry : ioTraits.entrySet()) {
            var handlerList = RecipeHandlerList.of(entry.getKey(), entry.getValue());
            this.addHandlerList(handlerList);
            traitSubscriptions.add(handlerList.subscribe(recipeLogic::updateTickSubscription));
        }
    }

    @Override
    public void onUnload() {
        super.onUnload();
        traitSubscriptions.forEach(ISubscription::unsubscribe);
        traitSubscriptions.clear();
        capabilitiesProxy.clear();
        capabilitiesFlat.clear();
        recipeLogic.inValid();
    }

    //////////////////////////////////////
    // ********** MISC ***********//
    //////////////////////////////////////
    @Override
    public void onMachineDestroyed() {
        super.onMachineDestroyed();
        importItems.dropInventoryInWorld();
        exportItems.dropInventoryInWorld();
    }

    public void setMuffled(boolean muffled) {
        isMuffled = muffled;
        syncDataHolder.markClientSyncFieldDirty("isMuffled");
    }

    //////////////////////////////////////
    // ******** OVERCLOCK *********//
    //////////////////////////////////////
    @Override
    public int getMaxOverclockTier() {
        return GTUtil.getTierByVoltage(Math.max(energyContainer.getInputVoltage(), energyContainer.getOutputVoltage()));
    }

    @Override
    public int getMinOverclockTier() {
        return 0;
    }

    @Override
    public void setOverclockTier(int tier) {
        if (!isRemote() && tier >= getMinOverclockTier() && tier <= getMaxOverclockTier()) {
            this.overclockTier = tier;
            this.recipeLogic.markLastRecipeDirty();
        }
    }

    @Override
    public long getOverclockVoltage() {
        return Math.min(GTValues.V[getOverclockTier()], Math.max(energyContainer.getInputVoltage(), energyContainer.getOutputVoltage()));
    }

    //////////////////////////////////////
    // ****** RECIPE LOGIC *******//
    //////////////////////////////////////
    @Override
    public void clientTick() {
        super.clientTick();
        if (previouslyMuffled != isMuffled) {
            previouslyMuffled = isMuffled;
            recipeLogic.updateSound();
        }
    }

    @Override
    public boolean keepSubscribing() {
        return false;
    }

    public GTRecipeType getRecipeType() {
        if (activeRecipeType >= recipeTypes.length) {
            GTCEu.LOGGER.warn("Preventing crash from bad recipe type index!");
            activeRecipeType = recipeTypes.length - 1;
        }
        return recipeTypes[activeRecipeType];
    }

    @ApiStatus.Internal
    @VisibleForTesting
    public void setRecipeType(GTRecipeType type) {
        int recipeIndex = -1;
        for (int i = 0; i < recipeTypes.length; i++) {
            if (type.equals(recipeTypes[i])) {
                recipeIndex = i;
                break;
            }
        }
        if (recipeIndex == -1) {
            var newer = new GTRecipeType[recipeTypes.length + 1];
            System.arraycopy(recipeTypes, 0, newer, 0, recipeTypes.length);
            newer[recipeTypes.length] = type;
            recipeTypes = newer;
            recipeIndex = recipeTypes.length - 1;
        }
        setActiveRecipeType(recipeIndex);
    }

    public RecipeLogic getRecipeLogic() {
        return this.recipeLogic;
    }

    public GTRecipeType[] getRecipeTypes() {
        return this.recipeTypes;
    }

    public int getActiveRecipeType() {
        return this.activeRecipeType;
    }

    public void setActiveRecipeType(final int activeRecipeType) {
        this.activeRecipeType = activeRecipeType;
    }

    public CleanroomReceiverTrait getCleanroomReceiver() {
        return this.cleanroomReceiver;
    }

    public Map<IO, List<RecipeHandlerList>> getCapabilitiesProxy() {
        return this.capabilitiesProxy;
    }

    public Map<IO, Map<RecipeCapability<?>, List<IRecipeHandler<?>>>> getCapabilitiesFlat() {
        return this.capabilitiesFlat;
    }

    public int getOverclockTier() {
        return this.overclockTier;
    }

    public boolean isMuffled() {
        return this.isMuffled;
    }
}
