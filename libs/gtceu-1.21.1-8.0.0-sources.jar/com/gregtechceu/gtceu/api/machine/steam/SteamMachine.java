package com.gregtechceu.gtceu.api.machine.steam;

import com.gregtechceu.gtceu.api.blockentity.BlockEntityCreationInfo;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.feature.ITieredMachine;
import com.gregtechceu.gtceu.api.machine.property.GTMachineModelProperties;
import com.gregtechceu.gtceu.api.machine.trait.NotifiableFluidTank;
import com.gregtechceu.gtceu.api.sync_system.annotations.SaveField;
import com.gregtechceu.gtceu.common.data.GTMaterials;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.neoforged.neoforge.fluids.FluidType;
import java.util.function.Function;
import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public abstract class SteamMachine extends MetaMachine implements ITieredMachine {
    public static final BooleanProperty STEEL_PROPERTY = GTMachineModelProperties.IS_STEEL_MACHINE;
    public final boolean isHighPressure;
    @SaveField
    public final NotifiableFluidTank steamTank;

    public SteamMachine(BlockEntityCreationInfo info, boolean isHighPressure, Function<SteamMachine, NotifiableFluidTank> steamTankFactory) {
        super(info);
        this.isHighPressure = isHighPressure;
        this.steamTank = steamTankFactory.apply(this);
        this.steamTank.setFilter(f -> f.getFluid().is(GTMaterials.Steam.getFluidTag()));
    }

    public SteamMachine(BlockEntityCreationInfo info, boolean isHighPressure) {
        this(info, isHighPressure, m -> new NotifiableFluidTank(m, 1, 16 * FluidType.BUCKET_VOLUME, IO.IN));
    }

    //////////////////////////////////////
    // ***** Initialization *****//
    //////////////////////////////////////
    @Override
    public int getTier() {
        return isHighPressure ? 1 : 0;
    }

    public boolean isHighPressure() {
        return this.isHighPressure;
    }
}
