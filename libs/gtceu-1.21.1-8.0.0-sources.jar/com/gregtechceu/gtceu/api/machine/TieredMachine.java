package com.gregtechceu.gtceu.api.machine;

import com.gregtechceu.gtceu.api.blockentity.BlockEntityCreationInfo;
import com.gregtechceu.gtceu.api.machine.feature.ITieredMachine;

public class TieredMachine extends MetaMachine implements ITieredMachine {
    protected final int tier;

    public TieredMachine(BlockEntityCreationInfo info, int tier) {
        super(info);
        this.tier = tier;
    }

    public int getTier() {
        return this.tier;
    }
}
