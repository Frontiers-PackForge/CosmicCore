package com.gregtechceu.gtceu.api.machine.multiblock.part;

import com.gregtechceu.gtceu.api.blockentity.BlockEntityCreationInfo;
import com.gregtechceu.gtceu.api.capability.recipe.IO;
import com.gregtechceu.gtceu.api.capability.recipe.IRecipeHandler;
import com.gregtechceu.gtceu.api.machine.MetaMachine;
import com.gregtechceu.gtceu.api.machine.feature.multiblock.IMultiPart;
import com.gregtechceu.gtceu.api.machine.multiblock.MultiblockControllerMachine;
import com.gregtechceu.gtceu.api.machine.property.GTMachineModelProperties;
import com.gregtechceu.gtceu.api.machine.trait.IRecipeHandlerTrait;
import com.gregtechceu.gtceu.api.machine.trait.RecipeHandlerList;
import com.gregtechceu.gtceu.api.sync_system.annotations.ClientFieldChangeListener;
import com.gregtechceu.gtceu.api.sync_system.annotations.SyncToClient;
import com.gregtechceu.gtceu.client.model.machine.MachineRenderState;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import it.unimi.dsi.fastutil.objects.ReferenceLinkedOpenHashSet;
import org.jetbrains.annotations.MustBeInvokedByOverriders;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.UnmodifiableView;
import java.util.*;

/**
 * The base class for all multiblock parts
 */
public class MultiblockPartMachine extends MetaMachine implements IMultiPart {
    @SyncToClient
    protected final Set<BlockPos> controllerPositions = new ObjectOpenHashSet<>(8);
    protected final SortedSet<MultiblockControllerMachine> controllers = new ReferenceLinkedOpenHashSet<>(8);
    @Nullable
    protected String substructureName;
    @Nullable
    private RecipeHandlerList handlerList;

    public MultiblockPartMachine(BlockEntityCreationInfo info) {
        super(info);
    }

    //////////////////////////////////////
    // ***** Initialization ******//
    //////////////////////////////////////
    @Override
    public boolean hasController(BlockPos controllerPos) {
        return controllerPositions.contains(controllerPos);
    }

    @Override
    public boolean isFormed() {
        return !controllerPositions.isEmpty();
    }

    // Not sure if necessary, but added to match the Controller class
    @ClientFieldChangeListener(fieldName = "controllerPositions")
    public void onControllersUpdated() {
        synchronized (controllers) {
            controllers.clear();
            for (BlockPos blockPos : controllerPositions) {
                if (MetaMachine.getMachine(getLevel(), blockPos) instanceof MultiblockControllerMachine controller) {
                    controllers.add(controller);
                }
            }
        }
    }

    @Override
    @UnmodifiableView
    public SortedSet<MultiblockControllerMachine> getControllers() {
        synchronized (controllers) {
            // Necessary to rebuild the set of controllers on client-side
            if (controllers.size() != controllerPositions.size()) {
                onControllersUpdated();
            }
            return Collections.unmodifiableSortedSet(new ReferenceLinkedOpenHashSet<>(controllers));
        }
    }

    public List<RecipeHandlerList> getRecipeHandlers() {
        return List.of(getHandlerList());
    }

    protected RecipeHandlerList getHandlerList() {
        if (handlerList == null) {
            List<IRecipeHandler<?>> handlers = new ArrayList<>();
            IO handlerIO = null;
            for (var trait : getAllTraits()) {
                if (trait instanceof IRecipeHandlerTrait<?> rht) {
                    if (handlerIO == null) handlerIO = rht.getHandlerIO();
                    handlers.add(rht);
                }
            }
            if (handlers.isEmpty()) {
                handlerList = RecipeHandlerList.NO_DATA;
            } else {
                handlerList = RecipeHandlerList.of(handlerIO, getPaintingColor(), handlers);
            }
        }
        return handlerList;
    }

    @Override
    public void onUnload() {
        super.onUnload();
        if (getLevel() instanceof ServerLevel serverLevel) {
            // Copy so we can call removedFromController (which mutates controllers) safely without CME
            Set<MultiblockControllerMachine> toIter;
            synchronized (controllers) {
                toIter = new ObjectOpenHashSet<>(controllers);
            }
            for (MultiblockControllerMachine controller : toIter) {
                if (serverLevel.isLoaded(controller.self().getBlockPos())) {
                    removedFromController(controller);
                    controller.onPartUnload();
                }
            }
        }
        controllerPositions.clear();
        synchronized (controllers) {
            controllers.clear();
        }
        substructureName = null;
    }

    //////////////////////////////////////
    // *** Multiblock LifeCycle ***//
    //////////////////////////////////////
    @MustBeInvokedByOverriders
    @Override
    public void removedFromController(MultiblockControllerMachine controller) {
        controllerPositions.remove(controller.getBlockPos());
        boolean empty;
        synchronized (controllers) {
            controllers.remove(controller);
            empty = controllers.isEmpty();
        }
        if (empty) {
            this.substructureName = null;
            MachineRenderState renderState = getRenderState();
            if (renderState.hasProperty(GTMachineModelProperties.IS_FORMED)) {
                setRenderState(renderState.setValue(GTMachineModelProperties.IS_FORMED, false));
            }
        }
        syncDataHolder.markClientSyncFieldDirty("controllerPositions");
    }

    @MustBeInvokedByOverriders
    @Override
    public void addedToController(MultiblockControllerMachine controller, String substructureName) {
        controllerPositions.add(controller.getBlockPos());
        synchronized (controllers) {
            controllers.add(controller);
        }
        this.substructureName = substructureName;
        syncDataHolder.markClientSyncFieldDirty("controllerPositions");
        MachineRenderState renderState = getRenderState();
        if (renderState.hasProperty(GTMachineModelProperties.IS_FORMED)) {
            setRenderState(renderState.setValue(GTMachineModelProperties.IS_FORMED, true));
        }
    }

    @Override
    public boolean replacePartModelWhenFormed() {
        var renderState = getRenderState();
        return renderState.hasProperty(GTMachineModelProperties.IS_FORMED) && renderState.getValue(GTMachineModelProperties.IS_FORMED);
    }

    @Override
    @Nullable
    public BlockState getFormedAppearance(@Nullable BlockState sourceState, @Nullable BlockPos sourcePos, Direction side) {
        if (!replacePartModelWhenFormed()) return null;
        return IMultiPart.super.getFormedAppearance(sourceState, sourcePos, side);
    }

    @Override
    public BlockState getBlockAppearance(BlockState state, BlockAndTintGetter level, BlockPos pos, Direction side, @Nullable BlockState sourceState, @Nullable BlockPos sourcePos) {
        if (isFormed()) {
            var appearance = getFormedAppearance(sourceState, sourcePos, side);
            if (appearance != null) return appearance;
        }
        return super.getBlockAppearance(state, level, pos, side, sourceState, sourcePos);
    }

    @Nullable
    public String getSubstructureName() {
        return this.substructureName;
    }
}
