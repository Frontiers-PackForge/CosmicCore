package com.gregtechceu.gtceu.api.machine.multiblock;

import com.gregtechceu.gtceu.api.GTValues;
import com.gregtechceu.gtceu.api.blockentity.BlockEntityCreationInfo;
import com.gregtechceu.gtceu.api.machine.feature.IOverclockMachine;
import com.gregtechceu.gtceu.api.machine.feature.ITieredMachine;
import com.gregtechceu.gtceu.api.machine.trait.recipe.RecipeLogic;
import com.gregtechceu.gtceu.api.sync_system.annotations.SaveField;

/**
 * @author screret
 * @date 2023/7/11
 * @implNote TieredWorkableElectricMultiblockMachine
 */
public class TieredWorkableElectricMultiblockMachine extends WorkableElectricMultiblockMachine implements ITieredMachine, IOverclockMachine {
    private final int tier;
    @SaveField
    protected int overclockTier;

    public TieredWorkableElectricMultiblockMachine(BlockEntityCreationInfo info, RecipeLogic recipeLogic, int tier) {
        super(info, recipeLogic);
        this.tier = tier;
    }

    public TieredWorkableElectricMultiblockMachine(BlockEntityCreationInfo info, int tier) {
        super(info);
        this.tier = tier;
    }

    //////////////////////////////////////
    // ***** Initialization ******//
    //////////////////////////////////////
    //////////////////////////////////////
    // ******** OVERCLOCK *********//
    //////////////////////////////////////
    @Override
    public int getMinOverclockTier() {
        return 0;
    }

    @Override
    public void setOverclockTier(int tier) {
        if (!isRemote() && tier >= getMinOverclockTier() && tier <= getMaxOverclockTier()) {
            this.overclockTier = tier;
            this.recipeLogic.markLastRecipeDirty();
        }
    }

    @Override
    public long getOverclockVoltage() {
        return Math.min(GTValues.V[getOverclockTier()], super.getOverclockVoltage());
    }

    //////////////////////////////////////
    // ****** RECIPE LOGIC *******//
    //////////////////////////////////////
    @Override
    public int getTier() {
        return Math.min(tier, super.getTier());
    }

    @Override
    public long getMaxVoltage() {
        return Math.min(GTValues.V[tier], super.getMaxVoltage());
    }

    public int getOverclockTier() {
        return this.overclockTier;
    }
}
