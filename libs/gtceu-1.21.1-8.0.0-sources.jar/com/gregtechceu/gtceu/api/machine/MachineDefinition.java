package com.gregtechceu.gtceu.api.machine;

import com.gregtechceu.gtceu.api.block.MetaMachineBlock;
import com.gregtechceu.gtceu.api.capability.recipe.RecipeCapability;
import com.gregtechceu.gtceu.api.data.RotationState;
import com.gregtechceu.gtceu.api.item.MetaMachineItem;
import com.gregtechceu.gtceu.api.machine.feature.IRecipeLogicMachine;
import com.gregtechceu.gtceu.api.machine.multiblock.PartAbility;
import com.gregtechceu.gtceu.api.mui.factory.PanelFactory;
import com.gregtechceu.gtceu.api.recipe.GTRecipe;
import com.gregtechceu.gtceu.api.recipe.GTRecipeType;
import com.gregtechceu.gtceu.api.recipe.modifier.RecipeModifier;
import com.gregtechceu.gtceu.api.recipe.modifier.RecipeModifierList;
import com.gregtechceu.gtceu.api.registry.registrate.builder.MachineBuilder;
import com.gregtechceu.gtceu.api.registry.registrate.provider.GTBlockstateProvider;
import com.gregtechceu.gtceu.client.model.machine.MachineRenderState;
import com.gregtechceu.gtceu.common.data.GTRecipeModifiers;
import com.gregtechceu.gtceu.config.ConfigHolder;
import com.gregtechceu.gtceu.utils.GTUtil;
import net.minecraft.core.Direction;
import net.minecraft.core.IdMapper;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.neoforged.neoforge.registries.DeferredHolder;
import brachy.modularui.theme.ThemeAPI;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.util.nullness.NonNullBiConsumer;
import it.unimi.dsi.fastutil.objects.Reference2IntMap;
import it.unimi.dsi.fastutil.objects.Reference2IntOpenHashMap;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import java.util.*;
import java.util.function.*;

/**
 * Representing basic information of a machine.
 */
public class MachineDefinition implements ItemLike {
    public static final IdMapper<MachineRenderState> RENDER_STATE_REGISTRY = new IdMapper<>(512);
    private final ResourceLocation id;
    // This is only stored here for KJS use.
    @Nullable
    private final String langValue;
    private final DeferredHolder<Block, ? extends MetaMachineBlock> blockHolder;
    private DeferredHolder<Item, ? extends MetaMachineItem> itemHolder;
    private Supplier<BlockEntityType<? extends MetaMachine>> blockEntityTypeSupplier;
    private final GTRecipeType[] recipeTypes;
    private final int tier;
    private final int defaultPaintingColor;
    private final RecipeModifier recipeModifier;
    private final boolean alwaysTryModifyRecipe;
    private final BiPredicate<IRecipeLogicMachine, @Nullable GTRecipe> beforeWorking;
    private final Predicate<IRecipeLogicMachine> onWorking;
    private final Consumer<IRecipeLogicMachine> onWaiting;
    private final Consumer<IRecipeLogicMachine> afterWorking;
    private final boolean regressWhenWaiting;
    /**
     * Whether this machine can be rotated or face upwards.
     */
    private final boolean allowExtendedFacing;
    private final RotationState rotationState;
    private final VoxelShape shape;
    private final Map<Direction, VoxelShape> cache = new EnumMap<>(Direction.class);
    private final BiConsumer<ItemStack, List<Component>> tooltipBuilder;
    private final Supplier<BlockState> appearance;
    private final boolean allowCoverOnFront;
    @Nullable
    private final PanelFactory UI;
    private final String themeId;
    private final Reference2IntMap<RecipeCapability<?>> recipeOutputLimits;
    private final StateDefinition<MachineDefinition, MachineRenderState> stateDefinition;
    private final MachineRenderState defaultRenderState;

    @SuppressWarnings({"unchecked", "rawtypes"})
    public MachineDefinition(ResourceLocation id, Properties properties) {
        this.id = id;
        this.rotationState = properties.rotationState();
        this.langValue = properties.langValue();
        this.UI = properties.ui();
        this.themeId = properties.themeId();
        this.recipeTypes = properties.recipeTypes();
        this.blockHolder = properties.blockHolder();
        this.itemHolder = properties.itemHolder();
        this.tier = properties.tier();
        this.recipeOutputLimits = properties.recipeOutputLimits();
        this.blockEntityTypeSupplier = properties.blockEntityTypeSupplier();
        this.tooltipBuilder = (itemStack, components) -> {
            properties.tooltips().forEach(t -> {
                Component c = t.get();
                if (c != null) components.add(c);
            });
            if (properties.tooltipBuilder() != null) properties.tooltipBuilder().accept(itemStack, components);
        };
        this.recipeModifier = properties.recipeModifier();
        this.alwaysTryModifyRecipe = properties.alwaysTryModifyRecipe();
        this.beforeWorking = properties.beforeWorking();
        this.onWorking = properties.onWorking();
        this.onWaiting = properties.onWaiting();
        this.afterWorking = properties.afterWorking();
        this.regressWhenWaiting = properties.regressWhenWaiting();
        this.allowCoverOnFront = properties.allowCoverOnFront();
        for (GTRecipeType type : recipeTypes) {
            if (type.getIconSupplier() == null) {
                type.setIconSupplier(this::asStack);
            }
        }
        if (properties.appearance() == null) {
            properties.appearance(() -> blockHolder.value().defaultBlockState());
        }
        this.appearance = properties.appearance();
        this.allowExtendedFacing = properties.allowExtendedFacing();
        this.shape = properties.shape();
        this.defaultPaintingColor = properties.paintingColor();
        // Initialise render state
        StateDefinition.Builder<MachineDefinition, MachineRenderState> builder = new StateDefinition.Builder<>(this);
        properties.modelProperties().keySet().forEach(builder::add);
        stateDefinition = builder.create(MachineDefinition::defaultRenderState, MachineRenderState::new);
        MachineRenderState defaultState = getStateDefinition().any();
        for (var entry : properties.modelProperties().entrySet()) {
            if (entry.getValue() == null) continue;
            defaultState = defaultState.setValue((Property) entry.getKey(), (Comparable) entry.getValue());
        }
        this.defaultRenderState = defaultState;
    }

    public boolean isTiered() {
        return tier != -1;
    }

    public MetaMachineBlock getBlock() {
        return blockHolder.get();
    }

    @Override
    public Item asItem() {
        return itemHolder.get();
    }

    public ItemStack asStack() {
        return new ItemStack(this);
    }

    public ItemStack asStack(int count) {
        return new ItemStack(this, count);
    }

    public BlockEntityType<? extends MetaMachine> getBlockEntityType() {
        return blockEntityTypeSupplier.get();
    }

    public VoxelShape getShape(Direction direction) {
        if (shape.isEmpty() || shape == Shapes.block() || direction == Direction.NORTH) return shape;
        return this.cache.computeIfAbsent(direction, dir -> GTUtil.rotateVoxelShape(shape, dir));
    }

    public String getName() {
        return id.getPath();
    }

    @Override
    public String toString() {
        return id.toString();
    }

    public String getDescriptionId() {
        return getBlock().getDescriptionId();
    }

    public BlockState defaultBlockState() {
        return getBlock().defaultBlockState();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MachineDefinition that = (MachineDefinition) o;
        return id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    static final ThreadLocal<@Nullable MachineDefinition> STATE = new ThreadLocal<>();

    @ApiStatus.Internal
    public static MachineDefinition getBuilt() {
        return Objects.requireNonNull(STATE.get());
    }

    @ApiStatus.Internal
    public static void setBuilt(MachineDefinition state) {
        STATE.set(state);
    }

    @ApiStatus.Internal
    public static void clearBuilt() {
        STATE.remove();
    }

    /**
     * Gets the input size for a machine for the capability with the machine having the specified recipe types
     */
    public int getInputSize(RecipeCapability<?> cap, GTRecipeType... recipeTypes) {
        int recipeTypeInputSize = 0;
        for (var recipeType : recipeTypes) {
            recipeTypeInputSize = Math.max(recipeType.getMaxInputs(cap), recipeTypeInputSize);
        }
        return recipeTypeInputSize;
    }

    /**
     * Gets the output size for a machine for the capability with the machine having the specified recipe types
     */
    public int getOutputSize(RecipeCapability<?> cap, GTRecipeType... recipeTypes) {
        int recipeTypeOutputSize = 0;
        for (var recipeType : recipeTypes) {
            recipeTypeOutputSize = Math.max(recipeType.getMaxOutputs(cap), recipeTypeOutputSize);
        }
        int machineTypeOutputLimit = this.getRecipeOutputLimits().getOrDefault(cap, recipeTypeOutputSize);
        return Math.min(recipeTypeOutputSize, machineTypeOutputLimit);
    }


    public static class Properties {
        private DeferredHolder<Block, ? extends MetaMachineBlock> blockHolder;
        private DeferredHolder<Item, ? extends MetaMachineItem> itemHolder;
        private Supplier<BlockEntityType<? extends MetaMachine>> blockEntityTypeSupplier;
        @Nullable
        private MachineBuilder.ModelInitializer model = null;
        @Nullable
        private NonNullBiConsumer<DataGenContext<Block, ? extends Block>, GTBlockstateProvider> blockModel = null;
        protected final Map<Property<?>, @Nullable Comparable<?>> modelProperties = new IdentityHashMap<>();
        private VoxelShape shape = Shapes.block();
        private RotationState rotationState = RotationState.NON_Y_AXIS;
        private boolean allowExtendedFacing = false;
        private boolean hasBER = ConfigHolder.INSTANCE.client.machinesHaveBERsByDefault;
        private GTRecipeType[] recipeTypes = new GTRecipeType[0];
        private int tier = -1;
        private Reference2IntMap<RecipeCapability<?>> recipeOutputLimits = new Reference2IntOpenHashMap<>();
        private int paintingColor = ConfigHolder.INSTANCE.client.getDefaultPaintingColor();
        private PartAbility[] abilities = new PartAbility[0];
        private final List<Supplier<? extends @Nullable Component>> tooltips = new ArrayList<>();
        @Nullable
        private BiConsumer<ItemStack, List<Component>> tooltipBuilder;
        private RecipeModifier recipeModifier = new RecipeModifierList(GTRecipeModifiers.OC_NON_PERFECT);
        private boolean alwaysTryModifyRecipe;
        private BiPredicate<IRecipeLogicMachine, GTRecipe> beforeWorking = (machine, recipe) -> true;
        private Predicate<IRecipeLogicMachine> onWorking = machine -> true;
        private Consumer<IRecipeLogicMachine> onWaiting = machine -> {
        };
        private Consumer<IRecipeLogicMachine> afterWorking = machine -> {
        };
        private boolean regressWhenWaiting = true;
        private boolean allowCoverOnFront = false;
        @Nullable
        private PanelFactory ui = null;
        private String themeId = ThemeAPI.DEFAULT_ID;
        @Nullable
        private Supplier<BlockState> appearance;
        @Nullable
        private String langValue = null;

        public DeferredHolder<Block, ? extends MetaMachineBlock> blockHolder() {
            return this.blockHolder;
        }

        public DeferredHolder<Item, ? extends MetaMachineItem> itemHolder() {
            return this.itemHolder;
        }

        public Supplier<BlockEntityType<? extends MetaMachine>> blockEntityTypeSupplier() {
            return this.blockEntityTypeSupplier;
        }

        @Nullable
        public MachineBuilder.ModelInitializer model() {
            return this.model;
        }

        @Nullable
        public NonNullBiConsumer<DataGenContext<Block, ? extends Block>, GTBlockstateProvider> blockModel() {
            return this.blockModel;
        }

        public Map<Property<?>, @Nullable Comparable<?>> modelProperties() {
            return this.modelProperties;
        }

        public VoxelShape shape() {
            return this.shape;
        }

        public RotationState rotationState() {
            return this.rotationState;
        }

        public boolean allowExtendedFacing() {
            return this.allowExtendedFacing;
        }

        public boolean hasBER() {
            return this.hasBER;
        }

        public GTRecipeType[] recipeTypes() {
            return this.recipeTypes;
        }

        public int tier() {
            return this.tier;
        }

        public Reference2IntMap<RecipeCapability<?>> recipeOutputLimits() {
            return this.recipeOutputLimits;
        }

        public int paintingColor() {
            return this.paintingColor;
        }

        public PartAbility[] abilities() {
            return this.abilities;
        }

        public List<Supplier<? extends @Nullable Component>> tooltips() {
            return this.tooltips;
        }

        @Nullable
        public BiConsumer<ItemStack, List<Component>> tooltipBuilder() {
            return this.tooltipBuilder;
        }

        public RecipeModifier recipeModifier() {
            return this.recipeModifier;
        }

        public boolean alwaysTryModifyRecipe() {
            return this.alwaysTryModifyRecipe;
        }

        public BiPredicate<IRecipeLogicMachine, GTRecipe> beforeWorking() {
            return this.beforeWorking;
        }

        public Predicate<IRecipeLogicMachine> onWorking() {
            return this.onWorking;
        }

        public Consumer<IRecipeLogicMachine> onWaiting() {
            return this.onWaiting;
        }

        public Consumer<IRecipeLogicMachine> afterWorking() {
            return this.afterWorking;
        }

        public boolean regressWhenWaiting() {
            return this.regressWhenWaiting;
        }

        public boolean allowCoverOnFront() {
            return this.allowCoverOnFront;
        }

        @Nullable
        public PanelFactory ui() {
            return this.ui;
        }

        public String themeId() {
            return this.themeId;
        }

        @Nullable
        public Supplier<BlockState> appearance() {
            return this.appearance;
        }

        @Nullable
        public String langValue() {
            return this.langValue;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties blockHolder(final DeferredHolder<Block, ? extends MetaMachineBlock> blockHolder) {
            this.blockHolder = blockHolder;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties itemHolder(final DeferredHolder<Item, ? extends MetaMachineItem> itemHolder) {
            this.itemHolder = itemHolder;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties blockEntityTypeSupplier(final Supplier<BlockEntityType<? extends MetaMachine>> blockEntityTypeSupplier) {
            this.blockEntityTypeSupplier = blockEntityTypeSupplier;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties model(@Nullable final MachineBuilder.ModelInitializer model) {
            this.model = model;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties blockModel(@Nullable final NonNullBiConsumer<DataGenContext<Block, ? extends Block>, GTBlockstateProvider> blockModel) {
            this.blockModel = blockModel;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties shape(final VoxelShape shape) {
            this.shape = shape;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties rotationState(final RotationState rotationState) {
            this.rotationState = rotationState;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties allowExtendedFacing(final boolean allowExtendedFacing) {
            this.allowExtendedFacing = allowExtendedFacing;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties hasBER(final boolean hasBER) {
            this.hasBER = hasBER;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties recipeTypes(final GTRecipeType[] recipeTypes) {
            this.recipeTypes = recipeTypes;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties tier(final int tier) {
            this.tier = tier;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties recipeOutputLimits(final Reference2IntMap<RecipeCapability<?>> recipeOutputLimits) {
            this.recipeOutputLimits = recipeOutputLimits;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties paintingColor(final int paintingColor) {
            this.paintingColor = paintingColor;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties abilities(final PartAbility[] abilities) {
            this.abilities = abilities;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties tooltipBuilder(@Nullable final BiConsumer<ItemStack, List<Component>> tooltipBuilder) {
            this.tooltipBuilder = tooltipBuilder;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties recipeModifier(final RecipeModifier recipeModifier) {
            this.recipeModifier = recipeModifier;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties alwaysTryModifyRecipe(final boolean alwaysTryModifyRecipe) {
            this.alwaysTryModifyRecipe = alwaysTryModifyRecipe;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties beforeWorking(final BiPredicate<IRecipeLogicMachine, GTRecipe> beforeWorking) {
            this.beforeWorking = beforeWorking;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties onWorking(final Predicate<IRecipeLogicMachine> onWorking) {
            this.onWorking = onWorking;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties onWaiting(final Consumer<IRecipeLogicMachine> onWaiting) {
            this.onWaiting = onWaiting;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties afterWorking(final Consumer<IRecipeLogicMachine> afterWorking) {
            this.afterWorking = afterWorking;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties regressWhenWaiting(final boolean regressWhenWaiting) {
            this.regressWhenWaiting = regressWhenWaiting;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties allowCoverOnFront(final boolean allowCoverOnFront) {
            this.allowCoverOnFront = allowCoverOnFront;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties ui(@Nullable final PanelFactory ui) {
            this.ui = ui;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties themeId(final String themeId) {
            this.themeId = themeId;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties appearance(@Nullable final Supplier<BlockState> appearance) {
            this.appearance = appearance;
            return this;
        }

        /**
         * @return {@code this}.
         */
        @org.jetbrains.annotations.NotNull
        public MachineDefinition.Properties langValue(@Nullable final String langValue) {
            this.langValue = langValue;
            return this;
        }
    }

    public ResourceLocation getId() {
        return this.id;
    }

    @Nullable
    public String getLangValue() {
        return this.langValue;
    }

    @ApiStatus.Internal
    public void setItemHolder(final DeferredHolder<Item, ? extends MetaMachineItem> itemHolder) {
        this.itemHolder = itemHolder;
    }

    public void setBlockEntityTypeSupplier(final Supplier<BlockEntityType<? extends MetaMachine>> blockEntityTypeSupplier) {
        this.blockEntityTypeSupplier = blockEntityTypeSupplier;
    }

    public GTRecipeType[] getRecipeTypes() {
        return this.recipeTypes;
    }

    public int getTier() {
        return this.tier;
    }

    public int getDefaultPaintingColor() {
        return this.defaultPaintingColor;
    }

    public RecipeModifier getRecipeModifier() {
        return this.recipeModifier;
    }

    public boolean isAlwaysTryModifyRecipe() {
        return this.alwaysTryModifyRecipe;
    }

    public BiPredicate<IRecipeLogicMachine, @Nullable GTRecipe> getBeforeWorking() {
        return this.beforeWorking;
    }

    public Predicate<IRecipeLogicMachine> getOnWorking() {
        return this.onWorking;
    }

    public Consumer<IRecipeLogicMachine> getOnWaiting() {
        return this.onWaiting;
    }

    public Consumer<IRecipeLogicMachine> getAfterWorking() {
        return this.afterWorking;
    }

    public boolean isRegressWhenWaiting() {
        return this.regressWhenWaiting;
    }

    /**
     * Whether this machine can be rotated or face upwards.
     */
    public boolean isAllowExtendedFacing() {
        return this.allowExtendedFacing;
    }

    public RotationState getRotationState() {
        return this.rotationState;
    }

    public BiConsumer<ItemStack, List<Component>> getTooltipBuilder() {
        return this.tooltipBuilder;
    }

    public Supplier<BlockState> getAppearance() {
        return this.appearance;
    }

    public boolean isAllowCoverOnFront() {
        return this.allowCoverOnFront;
    }

    @Nullable
    public PanelFactory getUI() {
        return this.UI;
    }

    public String getThemeId() {
        return this.themeId;
    }

    public Reference2IntMap<RecipeCapability<?>> getRecipeOutputLimits() {
        return this.recipeOutputLimits;
    }

    public StateDefinition<MachineDefinition, MachineRenderState> getStateDefinition() {
        return this.stateDefinition;
    }

    public MachineRenderState defaultRenderState() {
        return this.defaultRenderState;
    }
}
